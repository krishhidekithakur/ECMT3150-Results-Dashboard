(function () {
  const $ = (id) => document.getElementById(id);
  const legendTop = (el, items) => { const d = document.createElement('div'); el.appendChild(d); WF.legend(d, items); };
  const p3 = (p) => WF.fmt.pv(p);
  const L = { q: 'All' };

  function drawLadder(el, w) {
    const C = WF.C(), R = WF.rows('evidence_ladder'), qs = ['Reliable?', 'Early?', 'How?', 'Useful?'], col = { 'Reliable?': C.iem, 'Early?': C.fut, 'How?': C.kal, 'Useful?': C.c4 };
    WF.chips($('ctl-ladder'), [{ v: 'All', t: 'All' }].concat(qs.map((q) => ({ v: q, t: q }))), L.q, (v) => { L.q = v; WF.redraw(el); });
    legendTop(el, [{ c: C.fg, t: '\u25cf raw p' }, { c: C.fg, t: '\u25c6 multiplicity-adjusted' }]);
    const H = WF.h(w, 0.78, 330, 450), b = WF.base(el, w, H, { l: Math.min(230, w * 0.44), r: 44, b: 44, t: 8 });
    const x = d3.scaleLog([0.004, 1.5], [0, b.iw]), y = d3.scalePoint(R.map((d) => d.test), [10, b.ih - 6]).padding(0.4);
    WF.axX(b.g, x, b.ih, { vals: [0.005, 0.01, 0.05, 0.1, 0.5, 1], tf: (d) => d3.format('~g')(d) }); WF.xT(b, 'p-value (log scale)');
    b.g.append('rect').attr('x', 0).attr('width', x(0.05)).attr('y', 0).attr('height', b.ih).style('fill', 'var(--cds-chart-grid)').style('opacity', 0.45);
    WF.vline(b.g, x(0.05), 0, b.ih, { c: C.bad, d: '4 3' }); WF.lab(b.g, x(0.05) + 4, 10, '5%', { fill: C.bad });
    R.forEach((d) => {
      const on = L.q === 'All' || L.q === d.question, cy = y(d.test), cx = x(Math.max(0.004, d.p)), c = col[d.question];
      WF.lab(b.g, -8, cy, d.test, { a: 'end', v: 'middle', fill: on ? 'var(--color-fg)' : 'var(--color-fg-muted)' });
      WF.hline(b.g, cy, 0, b.iw, { c: 'var(--cds-chart-grid)', w: 1 });
      const m = d.adjusted === true ? b.g.append('path').attr('d', d3.symbol(d3.symbolDiamond, 150)()).attr('transform', `translate(${cx},${cy})`) : b.g.append('circle').attr('cx', cx).attr('cy', cy).attr('r', 6);
      m.style('fill', c).style('opacity', on ? 1 : 0.18).style('stroke', 'var(--color-bg)');
      if (on) WF.lab(b.g, cx + 11, cy, p3(d.p), { v: 'middle', fill: 'var(--color-fg)', w: 600 });
      WF.hover(m, () => ({ h: d.test, l: [{ c, t: d.question + ' ' + (d.adjusted === true ? '(adjusted)' : '(raw)') }, { t: 'p = ' + p3(d.p) }] }));
    });
  }
  function drawSizes(el, w) {
    const C = WF.C(), R = WF.rows('sample_sizes'), H = WF.h(w, 0.8, 300, 400);
    legendTop(el, [{ c: C.mute, t: 'Nominal rows' }, { c: C.fut, t: 'Independent units' }]);
    const b = WF.base(el, w, H, { l: Math.min(150, w * 0.32), r: 56, b: 40, t: 8 }), y0 = d3.scaleBand(R.map((d) => d.analysis), [0, b.ih]).padding(0.25), y1 = d3.scaleBand(['n', 'e'], [0, y0.bandwidth()]).padding(0.1);
    const x = d3.scaleLog([1, d3.max(R, (d) => d.nominal) * 1.6], [0, b.iw]); WF.axX(b.g, x, b.ih, { vals: [1, 10, 100, 1000], tf: d3.format(',') }); WF.axY(b.g, y0, b.iw, {}); WF.xT(b, 'Count (log scale)');
    R.forEach((d) => [['n', d.nominal, C.mute, 'Nominal rows'], ['e', d.effective, C.fut, d.effective_label]].forEach(([k, v, c, nm]) => {
      const r = b.g.append('rect').attr('x', 0).attr('width', Math.max(1, x(Math.max(1, v)))).attr('y', y0(d.analysis) + y1(k)).attr('height', y1.bandwidth()).attr('rx', 3).style('fill', c);
      WF.lab(b.g, x(Math.max(1, v)) + 6, y0(d.analysis) + y1(k) + y1.bandwidth() / 2, d3.format(',')(v), { v: 'middle', fill: 'var(--color-fg)', w: 600 }); WF.hover(r, () => ({ h: d.analysis, l: [{ c, t: nm + ': ' + d3.format(',')(v) }] }));
    }));
  }
  function drawProfile(el, w) {
    const C = WF.C(), R = WF.rows('event_profile'), pw = w > 560 ? (w - 16) / 2 : w, wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:16px'; el.appendChild(wrap);
    legendTop(el, [{ c: C.iem, t: 'IEM' }, { c: C.fut, t: 'Futures' }]);
    [['sd_iem', 'sd_fut', 'Implied standard deviation (bp)', d3.format('.1f')], ['pr_iem', 'pr_fut', 'Probability on the realised outcome', d3.format('.0%')]].forEach(([a, f, nm, tf]) => {
      const host = document.createElement('div'); host.style.width = pw + 'px'; wrap.appendChild(host); const b = WF.base(host, pw, WF.h(pw, 0.7, 220, 290), { l: 44, b: 40, t: 22 });
      const x = d3.scaleLinear([20, 1], [0, b.iw]), ext = d3.extent(R.flatMap((d) => [d[a], d[f]])), y = d3.scaleLinear([ext[0] - (ext[1] - ext[0]) * 0.1, ext[1] + (ext[1] - ext[0]) * 0.1], [b.ih, 0]);
      WF.axY(b.g, y, b.iw, { grid: true, n: 5, tf }); WF.axX(b.g, x, b.ih, { vals: [20, 15, 10, 5, 1], tf: d3.format('d') }); WF.xT(b, 'Trading days to the decision'); WF.lab(b.g, 0, -8, nm, { fill: 'var(--color-fg)', w: 600 });
      [[a, C.iem], [f, C.fut]].forEach(([k, c]) => { b.g.append('path').attr('d', d3.line().x((d) => x(d.trading_days_to_fomc)).y((d) => y(d[k]))(R)).style('fill', 'none').style('stroke', c).attr('stroke-width', 2.2); const dd = b.g.selectAll('.e' + k).data(R).join('circle').attr('class', 'e' + k).attr('cx', (d) => x(d.trading_days_to_fomc)).attr('cy', (d) => y(d[k])).attr('r', 2.6).style('fill', c); WF.hover(dd, (d) => ({ h: d.trading_days_to_fomc + ' trading days before', l: [{ c, t: nm + ' ' + tf(d[k]) }, { t: d.n + ' quotes' }] })); });
    });
  }

  // ----- traceability table -----
  const KS = { key: 'id', dir: 1 };
  function drawTable() {
    const rows = WF.rows('key_results'), t = $('kr-t'); if (!rows || !t) return;
    const q = ($('kr-q').value || '').toLowerCase(), st = $('kr-s').value;
    let r = rows.filter((d) => (!st || d.status === st) && (!q || (d.id + ' ' + d.quantity + ' ' + d.source_file + ' ' + d.report_location).toLowerCase().indexOf(q) >= 0));
    r = r.slice().sort((a, b) => { const x = a[KS.key], y = b[KS.key]; return (typeof x === 'number' && typeof y === 'number' ? (x || 0) - (y || 0) : String(x).localeCompare(String(y))) * KS.dir; });
    const tb = t.querySelector('tbody'); tb.replaceChildren();
    const nf = (v) => (Number.isFinite(v) ? WF.minus(d3.format('.5~g')(v)) : '');
    r.forEach((d) => {
      const tr = document.createElement('tr'); tr.setAttribute('data-key', d.id);
      [[d.id, ''], [d.quantity + (d.report_location ? ' (' + d.report_location + ')' : ''), ''], [nf(d.R_value), 'num'], [nf(d.report_value), 'num'], [d.status, 's-' + d.status], [d.source_file, '']].forEach(([v, c]) => { const td = document.createElement('td'); td.textContent = v; if (c) td.className = c; tr.appendChild(td); });
      tb.appendChild(tr);
    });
  }
  const hd = document.querySelectorAll('#kr-t th');
  hd.forEach((th) => th.addEventListener('click', () => { const k = th.getAttribute('data-field'); KS.dir = KS.key === k ? -KS.dir : 1; KS.key = k; drawTable(); }));
  $('kr-q').addEventListener('input', drawTable); $('kr-s').addEventListener('change', drawTable);
  WF.extra = [drawTable];

  WF.chart('#c-ladder', drawLadder); WF.chart('#c-sizes', drawSizes); WF.chart('#c-profile', drawProfile);
})();
