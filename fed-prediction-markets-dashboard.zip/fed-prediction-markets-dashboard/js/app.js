(function () {
  WF.hydrate();
  const root = document.querySelector('.wf');
  const go = (id, smooth) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.scrollIntoView({ behavior: smooth ? 'smooth' : 'auto', block: 'start' });
    dash.setLink(id);
  };
  root.addEventListener('click', (e) => {
    const a = e.target.closest('a[href^="#"]');
    if (!a) return;
    e.preventDefault();
    go(a.getAttribute('href').slice(1), true);
  });
  // scroll-spy for the nav
  const links = Array.from(document.querySelectorAll('#nav a'));
  const spy = new IntersectionObserver((es) => {
    es.forEach((e) => {
      if (e.isIntersecting) {
        links.forEach((l) => l.classList.toggle('on', l.getAttribute('data-t') === e.target.id));
        dash.setLink(e.target.id);
      }
    });
  }, { root: null, rootMargin: '-35% 0px -60% 0px', threshold: 0 });
  links.forEach((l) => { const s = document.getElementById(l.getAttribute('data-t')); if (s) spy.observe(s); });

  let opened = false;
  dash.onData(() => {
    WF.fill();
    WF.drawAll();
    (WF.extra || []).forEach((f) => { try { f(); } catch (e) { console.error(e); } });
    if (!opened && WF.rows('key_results')) {
      opened = true;
      const named = document.getElementById(location.hash.slice(1));
      if (named) setTimeout(() => go(named.id, false), 60);
    }
  });
})();
