(function () {
  const S = (WF.S.rel = { step: 0, variant: 'Clean', k: 0, ex25: false, hz: 'T-20', timer: null });
  const $ = (id) => document.getElementById(id);
  const HZ = ['T-20', 'T-10', 'T-5', 'T-1'];
  const HL = { 'T-20': 'T\u221220', 'T-10': 'T\u221210', 'T-5': 'T\u22125', 'T-1': 'T\u22121', Pooled: 'Pooled' };
  const TITLES = [
    ['Brier score by horizon', 'Clean futures benchmark. Lower is better.'],
    ['Cleaning the futures benchmark', 'How the gap shrinks as construction noise is removed.'],
    ['Every meeting, ranked by who won', 'Brier gap at T\u221220: IEM minus futures. Below zero, IEM was better. Click a dot.'],
    ['Drop the biggest IEM wins', 'The mean gap and p-value are recomputed from the meetings that remain.'],
    ['Reliability diagram', 'If stated odds are honest, the dots sit on the diagonal. Dot size is the number of forecasts.'],
    ['Where the IEM advantage comes from', 'Brier gap split into a reliability part and a resolution part. Left of zero favours IEM.'],
  ];
  const sm = (v) => WF.fmt.s3(v);

  function legendTop(el, items) { const d = document.createElement('div'); el.appendChild(d); WF.legend(d, items); }

  // ---------- step 0/1: Brier by horizon ----------
  function bHorizon(el, w) {
    const C = WF.C(), all = WF.rows('brier_horizon'), H = WF.h(w, 0.62, 280, 400);
    legendTop(el, [{ c: C.iem, t: 'IEM (prediction market)' }, { c: C.fut, t: 'Fed Funds futures (reconstructed)' }]);
    const b = WF.base(el, w, H, { l: 50, b: 44, t: 30 });
    const x0 = d3.scaleBand(HZ, [0, b.iw]).padding(0.3), x1 = d3.scaleBand(['iem', 'futures'], [0, x0.bandwidth()]).padding(0.1);
    const y = d3.scaleLinear([0, d3.max(all, (d) => d.futures) * 1.18], [b.ih, 0]);
    b.g.append('rect').attr('x', x0('T-20') - 8).attr('width', x0.bandwidth() + 16).attr('y', -8).attr('height', b.ih + 8).attr('rx', 6).style('fill', 'var(--color-panel)').style('stroke', 'var(--color-border-line)');
    WF.axY(b.g, y, b.iw, { grid: true, n: 5, tf: WF.fmt.f2 }); WF.axX(b.g, x0, b.ih, { tf: (d) => HL[d] }); WF.yT(b, 'Brier score');
    const L = b.g.append('g'), T = b.g.append('g'), G = b.g.append('g');
    return function upd() {
      const v = S.step === 0 ? 'Clean' : S.variant, rows = all.filter((r) => r.variant === v);
      const data = HZ.flatMap((h) => { const r = rows.find((q) => q.horizon === h); return r ? [{ h, m: 'iem', v: r.iem, r }, { h, m: 'futures', v: r.futures, r }] : []; });
      const bars = L.selectAll('rect').data(data, (d) => d.h + d.m).join((e) => e.append('rect').attr('x', (d) => x0(d.h) + x1(d.m)).attr('width', x1.bandwidth()).attr('y', b.ih).attr('height', 0).attr('rx', 3).style('fill', (d) => (d.m === 'iem' ? C.iem : C.fut)));
      bars.transition().duration(550).attr('y', (d) => y(d.v)).attr('height', (d) => b.ih - y(d.v));
      WF.hover(bars, (d) => ({ h: HL[d.h] + ' \u00b7 ' + (d.m === 'iem' ? 'IEM' : 'Futures') + ' \u00b7 ' + v + ' benchmark', l: [{ c: d.m === 'iem' ? C.iem : C.fut, t: 'Brier ' + WF.fmt.f3(d.v) }, { t: 'Gap ' + sm(d.r.gap) + ' (SE ' + WF.fmt.f3(d.r.se) + ')' }] }));
      T.selectAll('text').data(data, (d) => d.h + d.m).join('text').attr('x', (d) => x0(d.h) + x1(d.m) + x1.bandwidth() / 2).attr('text-anchor', 'middle').style('fill', 'var(--color-fg-muted)').style('font-size', '11px')
        .text((d) => WF.fmt.f3(d.v)).transition().duration(550).attr('y', (d) => y(d.v) - 5);
      G.selectAll('*').remove();
      const r20 = rows.find((q) => q.horizon === 'T-20');
      if (r20) { WF.lab(G, x0('T-20') + x0.bandwidth() / 2, -14, 'T\u221220 gap ' + sm(r20.gap), { a: 'middle', fill: 'var(--color-fg)', w: 600, s: 12 }); }
    };
  }

  // ---------- step 2/3: ranked dot plot with drop-k ----------
  function bRank(el, w) {
    const C = WF.C(), all = WF.rows('meetings_t20').slice().sort((a, b) => a.gap - b.gap); all.forEach((d, i) => (d.rank = i + 1));
    const H = WF.h(w, 0.72, 300, 440), b = WF.base(el, w, H, { l: 50, b: 40, t: 34 });
    const x = d3.scaleLinear([0.5, all.length + 0.5], [0, b.iw]);
    const y = d3.scaleLinear([d3.min(all, (d) => d.gap) - 0.12, Math.max(0.8, d3.max(all, (d) => d.gap) + 0.12)], [b.ih, 0]);
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f1 }); WF.axX(b.g, x, b.ih, { n: 6, tf: d3.format('d') });
    WF.xT(b, 'Meetings, ranked from most IEM-favourable to most futures-favourable'); WF.yT(b, 'Brier gap, IEM minus futures');
    WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
    WF.lab(b.g, b.iw - 4, y(0) - 7, 'futures better \u2191', { a: 'end', fill: C.fut, w: 600 }); WF.lab(b.g, b.iw - 4, y(0) + 15, 'IEM better \u2193', { a: 'end', fill: C.iem, w: 600 });
    const mean = b.g.append('line').attr('x1', 0).attr('x2', b.iw).style('stroke', C.fg).attr('stroke-dasharray', '5 4').attr('stroke-width', 1.2);
    const lbl = b.g.append('g'), dots = b.g.append('g'), ring = b.g.append('circle').attr('r', 8).style('fill', 'none').style('stroke', C.fg).attr('stroke-width', 2).style('display', 'none');
    const ro = WF.lab(b.g, 0, -16, '', { fill: 'var(--color-fg)', s: 12, w: 600 }), ro2 = WF.lab(b.g, 0, -3, '', { s: 11 });
    return function upd() {
      const k = S.step === 3 ? S.k : 0, ex = S.step === 3 && S.ex25, gone = new Set();
      if (ex) all.forEach((d) => { if (Math.abs(d.actual_change_bp) > 25) gone.add(d.meeting); });
      all.filter((d) => !gone.has(d.meeting)).slice(0, k).forEach((d) => gone.add(d.meeting));
      const kept = all.filter((d) => !gone.has(d.meeting)), st = WF.stats(kept.map((d) => d.gap));
      const dd = dots.selectAll('circle').data(all, (d) => d.meeting).join((e) => e.append('circle').attr('cx', (d) => x(d.rank)).attr('cy', (d) => y(d.gap)).attr('r', 4.2).style('cursor', 'pointer'));
      dd.transition().duration(350).style('fill', (d) => (gone.has(d.meeting) ? 'none' : d.gap < 0 ? C.iem : C.fut)).style('stroke', (d) => (gone.has(d.meeting) ? C.mute : 'none')).attr('stroke-width', 1.4).style('opacity', (d) => (gone.has(d.meeting) ? 0.7 : 0.92));
      dd.on('click', (ev, d) => WF.selectMeeting(d.meeting, true));
      WF.hover(dd, (d) => ({ h: d.meeting + ' \u00b7 ' + d.move, l: [{ c: C.iem, t: 'IEM Brier ' + WF.fmt.f3(d.BS_iem) }, { c: C.fut, t: 'Futures Brier ' + WF.fmt.f3(d.BS_fut) }, { t: 'Gap ' + sm(d.gap) + (gone.has(d.meeting) ? ' (dropped)' : '') }, { t: 'Click to open in the explorer' }] }));
      mean.transition().duration(350).attr('y1', y(st.mean)).attr('y2', y(st.mean));
      lbl.selectAll('text').data(all.slice(0, 3), (d) => d.meeting).join('text').attr('x', (d) => x(d.rank) + 8).attr('y', (d) => y(d.gap) + 4).style('fill', 'var(--color-fg-muted)').style('font-size', '11px').text((d) => d.meeting + ' ' + d.move);
      ro.text('Mean gap ' + sm(st.mean) + ' over ' + st.n + ' meetings'); ro2.text('t = ' + WF.fmt.f2(st.t) + ', p = ' + WF.fmt.pv(st.p) + (gone.size ? ' (' + gone.size + ' dropped)' : ' (all meetings)'));
      const s = all.find((d) => d.meeting === WF.sel); if (s) ring.style('display', null).attr('cx', x(s.rank)).attr('cy', y(s.gap)); else ring.style('display', 'none');
    };
  }

  // ---------- step 4: reliability diagram ----------
  function bCalib(el, w) {
    const C = WF.C(), all = WF.rows('reliability_bins');
    legendTop(el, [{ c: C.iem, t: 'IEM' }, { c: C.fut, t: 'Futures (reconstructed)' }]);
    const sz = Math.min(w, 520), H = Math.round(sz * 0.92), b = WF.base(el, w, H, { l: 52, b: 46, t: 10 });
    const x = d3.scaleLinear([0, 1], [0, b.iw]), y = d3.scaleLinear([0, 1], [b.ih, 0]), r = d3.scaleSqrt([0, d3.max(all, (d) => d.n)], [2, 13]);
    WF.axY(b.g, y, b.iw, { grid: true, n: 5, tf: d3.format('.0%') }); WF.axX(b.g, x, b.ih, { n: 5, tf: d3.format('.0%') });
    WF.xT(b, 'Stated probability'); WF.yT(b, 'How often the outcome happened');
    b.g.append('line').attr('x1', x(0)).attr('y1', y(0)).attr('x2', x(1)).attr('y2', y(1)).style('stroke', 'var(--cds-chart-reference)').attr('stroke-dasharray', '5 4');
    const lay = b.g.append('g');
    return function upd() {
      lay.selectAll('*').remove();
      ['IEM', 'Futures'].forEach((m) => {
        const rows = all.filter((d) => d.horizon === S.hz && d.market === m).sort((p, q) => p.mean_p - q.mean_p), col = m === 'IEM' ? C.iem : C.fut;
        lay.append('path').attr('d', d3.line().x((d) => x(d.mean_p)).y((d) => y(d.freq))(rows)).style('fill', 'none').style('stroke', col).attr('stroke-width', 2).attr('stroke-linejoin', 'round');
        const c = lay.selectAll('.p' + m).data(rows).join('circle').attr('class', 'p' + m).attr('cx', (d) => x(d.mean_p)).attr('cy', (d) => y(d.freq)).attr('r', (d) => r(d.n)).style('fill', col).style('opacity', 0.55).style('stroke', col);
        WF.hover(c, (d) => ({ h: m + ' \u00b7 ' + HL[S.hz], l: [{ t: 'Stated ' + d3.format('.0%')(d.mean_p) }, { t: 'Happened ' + d3.format('.0%')(d.freq) }, { t: d.n + ' forecasts' }] }));
      });
    };
  }

  // ---------- step 5: where the gap comes from ----------
  function bMurphy(el, w) {
    const C = WF.C(), M = WF.rows('murphy'), H = WF.h(w, 0.62, 270, 380);
    legendTop(el, [{ c: C.c4, t: 'Reliability (honest odds)' }, { c: C.c5, t: 'Resolution (telling meetings apart)' }, { c: C.fg, t: '\u25c6 net gap' }]);
    const b = WF.base(el, w, H, { l: 64, b: 42, t: 12 }), hs = ['T-20', 'T-10', 'T-5', 'T-1', 'Pooled'];
    const g = (h, m, f) => { const r = M.find((q) => q.horizon === h && q.market === m); return r ? r[f] : NaN; };
    const parts = hs.map((h) => ({ h, rel: g(h, 'IEM', 'reliability') - g(h, 'Futures', 'reliability'), res: -(g(h, 'IEM', 'resolution') - g(h, 'Futures', 'resolution')) }));
    const ext = d3.extent(parts.flatMap((p) => [p.rel, p.res, p.rel + p.res, 0])), pad = 0.015;
    const x = d3.scaleLinear([ext[0] - pad, ext[1] + pad], [0, b.iw]), y = d3.scaleBand(hs, [0, b.ih]).padding(0.28);
    WF.axX(b.g, x, b.ih, { n: 6, tf: WF.fmt.f2 }); WF.axY(b.g, y, b.iw, { tf: (d) => HL[d] }); WF.xT(b, 'Contribution to the Brier gap (IEM minus futures)');
    WF.vline(b.g, x(0), 0, b.ih, { c: 'var(--cds-chart-axis)' });
    parts.forEach((p) => {
      let neg = 0, pos = 0;
      [['rel', C.c4, 'Reliability'], ['res', C.c5, 'Resolution']].forEach(([k, col, nm]) => {
        const v = p[k]; let a0, a1; if (v < 0) { a0 = neg + v; a1 = neg; neg += v; } else { a0 = pos; a1 = pos + v; pos += v; }
        const rect = b.g.append('rect').attr('x', x(a0)).attr('width', Math.max(1, x(a1) - x(a0))).attr('y', y(p.h)).attr('height', y.bandwidth()).attr('rx', 3).style('fill', col);
        WF.hover(rect, () => ({ h: HL[p.h] + ' \u00b7 ' + nm, l: [{ c: col, t: sm(v) + (v < 0 ? ' (favours IEM)' : ' (favours futures)') }] }));
        if (x(a1) - x(a0) > 38) WF.lab(b.g, (x(a0) + x(a1)) / 2, y(p.h) + y.bandwidth() / 2, WF.fmt.s3(v).replace('+', '+'), { a: 'middle', v: 'middle', fill: 'var(--color-bg)', w: 600 });
      });
      const dm = b.g.append('path').attr('d', d3.symbol(d3.symbolDiamond, 90)()).attr('transform', `translate(${x(p.rel + p.res)},${y(p.h) + y.bandwidth() / 2})`).style('fill', C.fg).style('stroke', 'var(--color-bg)');
      WF.hover(dm, () => ({ h: HL[p.h] + ' \u00b7 net', l: [{ t: 'Net gap ' + sm(p.rel + p.res) }] }));
    });
    return function upd() {};
  }

  function drawStage(el, w, fresh) {
    if (fresh || el.__mode !== S.step) { el.replaceChildren(); el.__mode = S.step; el.__upd = [bHorizon, bHorizon, bRank, bRank, bCalib, bMurphy][S.step](el, w); }
    el.__upd();
  }

  function ctlRender() {
    const c = $('ctl-rel'); c.replaceChildren(); const el = $('c-rel');
    const redraw = () => { ctlRender(); WF.redraw(el); };
    if (S.step === 1) {
      WF.chips(c, [{ v: 'Naive', t: 'Naive' }, { v: 'Amplification <= 3', t: 'Amplification \u2264 3' }, { v: 'Clean', t: 'Clean' }], S.variant, (v) => { stopPlay(); S.variant = v; redraw(); });
      const p = document.createElement('button'); p.type = 'button'; p.className = 'chip'; p.textContent = S.timer ? '\u25a0 Stop' : '\u25b6 Clean it up'; p.addEventListener('click', () => (S.timer ? (stopPlay(), redraw()) : startPlay())); c.appendChild(p);
    } else if (S.step === 3) {
      const l = document.createElement('label'); const sp = document.createElement('b'); sp.textContent = S.k; const inp = document.createElement('input'); inp.type = 'range'; inp.min = 0; inp.max = 12; inp.step = 1; inp.value = S.k;
      l.append('Drop the ', sp, ' biggest IEM wins ', inp); inp.addEventListener('input', () => { S.k = +inp.value; sp.textContent = S.k; WF.redraw(el); }); c.appendChild(l);
      const l2 = document.createElement('label'); const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = S.ex25; l2.append(cb, 'Exclude moves above 25bp'); cb.addEventListener('change', () => { S.ex25 = cb.checked; WF.redraw(el); }); c.appendChild(l2);
    } else if (S.step === 4) {
      WF.chips(c, HZ.map((h) => ({ v: h, t: HL[h] })), S.hz, (v) => { S.hz = v; redraw(); });
    }
  }
  function startPlay() {
    const seq = ['Naive', 'Amplification <= 3', 'Clean']; let i = 0; S.variant = seq[0]; const el = $('c-rel');
    S.timer = setInterval(() => { i++; if (i >= seq.length) { stopPlay(); } else S.variant = seq[i]; ctlRender(); WF.redraw(el); }, 1500); ctlRender(); WF.redraw(el);
  }
  function stopPlay() { if (S.timer) { clearInterval(S.timer); S.timer = null; } }

  function setStep(i) {
    if (i === S.step && $('ttl-rel').textContent) return;
    stopPlay(); S.step = i; $('ttl-rel').textContent = TITLES[i][0]; $('note-rel').textContent = TITLES[i][1]; ctlRender(); WF.redraw($('c-rel'));
  }

  // ---------- explore: meeting explorer ----------
  function drawMx(el, w) {
    const C = WF.C(), M = WF.rows('meetings_t20'), P = WF.rows('meeting_paths'), sel = $('mx-sel');
    const byDate = M.slice().sort((a, b) => (a.meeting < b.meeting ? -1 : 1));
    if (!sel.options.length) byDate.forEach((d) => sel.appendChild(new Option(d.meeting + ' \u00b7 ' + d.move + ' \u00b7 gap ' + WF.minus(d3.format('+.2f')(d.gap)), d.meeting)));
    if (!WF.sel) WF.sel = M.slice().sort((a, b) => a.gap - b.gap)[0].meeting;
    sel.value = WF.sel;
    const m = M.find((d) => d.meeting === WF.sel), rows = P.filter((d) => d.meeting === WF.sel);
    $('mx-note').textContent = m.meeting + ': the Fed chose \u201c' + m.move + '\u201d. Brier at T\u221220: IEM ' + WF.fmt.f3(m.BS_iem) + ', futures ' + WF.fmt.f3(m.BS_fut) + ' (gap ' + sm(m.gap) + ', ' + (m.gap < 0 ? 'IEM better' : 'futures better') + ').';
    const H = WF.h(w, 0.36, 250, 330), b = WF.base(el, w, H, { l: 48, r: 14, b: 40, t: 24 }), gp = 44, pw = (b.iw - gp) / 2;
    const days = d3.extent(rows, (d) => d.days_to_fomc), x = d3.scaleLinear([Math.max(20, days[1] || 20), 0.5], [0, pw]);
    const L = b.g.append('g'), R = b.g.append('g').attr('transform', `translate(${pw + gp},0)`);
    const yp = d3.scaleLinear([0, 1], [b.ih, 0]); WF.axY(L, yp, pw, { grid: true, n: 5, tf: d3.format('.0%') }); WF.axX(L, x, b.ih, { n: 5, tf: d3.format('d') });
    WF.lab(L, 0, -9, 'Probability on what actually happened', { fill: 'var(--color-fg)', w: 600 }); WF.lab(L, pw / 2, b.ih + 34, 'Trading days to the decision', { a: 'middle' });
    const ev = rows.map((d) => d.expected_move_bp).filter(Number.isFinite).concat([m.actual_change_bp, 0]), ye = d3.scaleLinear(d3.extent(ev), [b.ih, 0]).nice();
    WF.axY(R, ye, pw, { grid: true, n: 5, tf: d3.format('d') }); WF.axX(R, x, b.ih, { n: 5, tf: d3.format('d') });
    WF.lab(R, 0, -9, 'Expected policy move (bp)', { fill: 'var(--color-fg)', w: 600 }); WF.lab(R, pw / 2, b.ih + 34, 'Trading days to the decision', { a: 'middle' });
    WF.hline(R, ye(m.actual_change_bp), 0, pw, { c: C.fg, d: '5 4' }); WF.lab(R, pw - 2, ye(m.actual_change_bp) - 5, 'actual: ' + m.move, { a: 'end', fill: 'var(--color-fg)' });
    [['IEM', C.iem], ['Futures', C.fut]].forEach(([mk, col]) => {
      const r = rows.filter((d) => d.market === mk).sort((p, q) => q.days_to_fomc - p.days_to_fomc);
      L.append('path').attr('d', d3.line().x((d) => x(d.days_to_fomc)).y((d) => yp(d.prob_realised_outcome))(r)).style('fill', 'none').style('stroke', col).attr('stroke-width', 2).attr('stroke-linejoin', 'round');
      R.append('path').attr('d', d3.line().defined((d) => Number.isFinite(d.expected_move_bp)).x((d) => x(d.days_to_fomc)).y((d) => ye(d.expected_move_bp))(r)).style('fill', 'none').style('stroke', col).attr('stroke-width', 2).attr('stroke-linejoin', 'round');
      L.selectAll('.d' + mk).data(r).join('circle').attr('class', 'd' + mk).attr('cx', (d) => x(d.days_to_fomc)).attr('cy', (d) => yp(d.prob_realised_outcome)).attr('r', 2.6).style('fill', col);
    });
    const ov = L.append('rect').attr('width', pw).attr('height', b.ih).style('fill', 'transparent');
    ov.on('mousemove touchmove', (e) => { const px = d3.pointer(e.touches ? e.touches[0] : e)[0], dd = Math.round(x.invert(px)); const t = rows.filter((d) => d.days_to_fomc === dd); if (t.length) { const i = t.find((d) => d.market === 'IEM'), f = t.find((d) => d.market === 'Futures'); WF.tipShow(e.touches ? e.touches[0] : e, dd + ' trading days before', [i && { c: C.iem, t: 'IEM ' + d3.format('.0%')(i.prob_realised_outcome) }, f && { c: C.fut, t: 'Futures ' + d3.format('.0%')(f.prob_realised_outcome) }].filter(Boolean)); } }).on('mouseleave', WF.tipHide);
    legendTop(el, [{ c: C.iem, t: 'IEM' }, { c: C.fut, t: 'Futures' }]);
  }
  function mxStep(d) { const M = WF.rows('meetings_t20'); if (!M) return; const s = M.slice().sort((a, b) => (a.meeting < b.meeting ? -1 : 1)), i = s.findIndex((x) => x.meeting === WF.sel); WF.selectMeeting(s[Math.max(0, Math.min(s.length - 1, i + d))].meeting); }
  $('mx-sel').addEventListener('change', (e) => WF.selectMeeting(e.target.value));
  $('mx-win').addEventListener('click', () => { const M = WF.rows('meetings_t20'); if (M) WF.selectMeeting(M.slice().sort((a, b) => a.gap - b.gap)[0].meeting); });
  $('mx-lose').addEventListener('click', () => { const M = WF.rows('meetings_t20'); if (M) WF.selectMeeting(M.slice().sort((a, b) => b.gap - a.gap)[0].meeting); });
  $('mx-prev').addEventListener('click', () => mxStep(-1)); $('mx-next').addEventListener('click', () => mxStep(1));

  // ---------- explore: expected-move scatter ----------
  function drawSc(el, w) {
    const C = WF.C(), M = WF.rows('meetings_t20').filter((d) => Number.isFinite(d.E_iem) && Number.isFinite(d.E_fut)), H = WF.h(w, 0.8, 300, 400);
    legendTop(el, [{ c: C.c4, t: 'Cut' }, { c: C.mute, t: 'Hold' }, { c: C.c5, t: 'Hike' }]);
    const b = WF.base(el, w, H, { l: 50, b: 42, t: 8 }), ext = d3.extent(M.flatMap((d) => [d.E_iem, d.E_fut])), ticks = [-100, -50, -25, -10, 0, 10, 25].filter((t) => t >= ext[0] - 5 && t <= ext[1] + 5);
    const mk = () => d3.scaleSymlog().constant(10).domain([ext[0] - 4, ext[1] + 4]);
    const x = mk().range([0, b.iw]), y = mk().range([b.ih, 0]);
    WF.axX(b.g, x, b.ih, { vals: ticks, tf: d3.format('d') }); WF.axY(b.g, y, b.iw, { vals: ticks, tf: d3.format('d'), grid: true });
    WF.xT(b, 'Futures-implied expected move (bp)'); WF.yT(b, 'IEM-implied expected move (bp)');
    b.g.append('line').attr('x1', x(ext[0])).attr('y1', y(ext[0])).attr('x2', x(ext[1])).attr('y2', y(ext[1])).style('stroke', 'var(--cds-chart-reference)').attr('stroke-dasharray', '5 4');
    const col = (d) => (d.actual_change_bp < 0 ? C.c4 : d.actual_change_bp > 0 ? C.c5 : C.mute);
    const dots = b.g.selectAll('circle').data(M).join('circle').attr('cx', (d) => x(d.E_fut)).attr('cy', (d) => y(d.E_iem)).attr('r', (d) => (d.meeting === WF.sel ? 6.5 : 4.2)).style('fill', col).style('opacity', 0.85).style('stroke', (d) => (d.meeting === WF.sel ? C.fg : 'none')).attr('stroke-width', 2).style('cursor', 'pointer');
    dots.on('click', (e, d) => WF.selectMeeting(d.meeting));
    WF.hover(dots, (d) => ({ h: d.meeting + ' \u00b7 ' + d.move, l: [{ t: 'IEM expects ' + WF.fmt.f1(d.E_iem) + 'bp' }, { t: 'Futures imply ' + WF.fmt.f1(d.E_fut) + 'bp' }] }));
  }

  // ---------- explore: gap through time ----------
  function drawGt(el, w) {
    const C = WF.C(), M = WF.rows('meetings_t20').map((d) => Object.assign({ t: WF.pd(d.meeting) }, d)), H = WF.h(w, 0.62, 270, 360);
    const b = WF.base(el, w, H, { l: 48, b: 34, t: 8 }), x = d3.scaleUtc(d3.extent(M, (d) => d.t), [0, b.iw]), y = d3.scaleLinear(d3.extent(M, (d) => d.gap), [b.ih, 0]).nice();
    b.g.append('rect').attr('x', x(WF.pd('2008-12-16'))).attr('width', Math.max(0, x(WF.pd('2015-12-16')) - x(WF.pd('2008-12-16')))).attr('y', 0).attr('height', b.ih).style('fill', 'var(--cds-chart-grid)').style('opacity', 0.5);
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f1 }); WF.axX(b.g, x, b.ih, { n: 7 }); WF.yT(b, 'Brier gap (below 0: IEM better)'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
    const r = d3.scaleSqrt([0, 50], [3, 9]);
    const dots = b.g.selectAll('circle').data(M).join('circle').attr('cx', (d) => x(d.t)).attr('cy', (d) => y(d.gap)).attr('r', (d) => r(Math.abs(d.actual_change_bp))).style('fill', (d) => (d.gap < 0 ? C.iem : C.fut)).style('opacity', 0.78).style('stroke', (d) => (d.meeting === WF.sel ? C.fg : 'none')).attr('stroke-width', 2).style('cursor', 'pointer');
    dots.on('click', (e, d) => WF.selectMeeting(d.meeting));
    WF.hover(dots, (d) => ({ h: d.meeting + ' \u00b7 ' + d.move, l: [{ t: 'Gap ' + sm(d.gap) }] }));
  }

  // ---------- explore: gap by what the Fed did ----------
  function drawGm(el, w) {
    const C = WF.C(), M = WF.rows('meetings_t20'), H = WF.h(w, 0.38, 250, 330);
    const cls = (d) => { const v = d.actual_change_bp; return v <= -50 ? 'Cut \u226550bp' : v < 0 ? 'Cut 25bp' : v === 0 ? 'Hold' : v < 50 ? 'Hike 25bp' : 'Hike \u226550bp'; };
    const cats = ['Cut \u226550bp', 'Cut 25bp', 'Hold', 'Hike 25bp', 'Hike \u226550bp'], b = WF.base(el, w, H, { l: 48, b: 44, t: 10 });
    const x = d3.scaleBand(cats, [0, b.iw]).padding(0.2), y = d3.scaleLinear(d3.extent(M, (d) => d.gap), [b.ih, 0]).nice();
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f1 }); WF.axX(b.g, x, b.ih); WF.yT(b, 'Brier gap at T\u221220'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
    cats.forEach((cat) => {
      const rows = M.filter((d) => cls(d) === cat); if (!rows.length) return;
      const cx = x(cat) + x.bandwidth() / 2, mu = d3.mean(rows, (d) => d.gap);
      b.g.append('line').attr('x1', cx - x.bandwidth() * 0.4).attr('x2', cx + x.bandwidth() * 0.4).attr('y1', y(mu)).attr('y2', y(mu)).style('stroke', C.fg).attr('stroke-width', 3);
      const dots = b.g.selectAll('.s' + cat.length + cat.charCodeAt(1)).data(rows).join('circle').attr('cx', (d, i) => cx + Math.sin(i * 12.9898 + cat.length) * x.bandwidth() * 0.32).attr('cy', (d) => y(d.gap)).attr('r', 4).style('fill', (d) => (d.gap < 0 ? C.iem : C.fut)).style('opacity', 0.75).style('cursor', 'pointer');
      dots.on('click', (e, d) => WF.selectMeeting(d.meeting)); WF.hover(dots, (d) => ({ h: d.meeting + ' \u00b7 ' + d.move, l: [{ t: 'Gap ' + sm(d.gap) }] }));
      WF.lab(b.g, cx, b.ih + 30, 'n = ' + rows.length + ', mean ' + sm(mu), { a: 'middle' });
    });
  }

  WF.chart('#c-rel', drawStage); WF.chart('#c-mx', drawMx); WF.chart('#c-sc', drawSc); WF.chart('#c-gt', drawGt); WF.chart('#c-gm', drawGm);
  WF.scrolly('chaps-rel', setStep);
  $('ttl-rel').textContent = TITLES[0][0]; $('note-rel').textContent = TITLES[0][1];
})();
