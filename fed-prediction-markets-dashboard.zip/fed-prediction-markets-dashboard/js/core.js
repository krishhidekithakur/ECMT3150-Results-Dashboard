(function () {
  const WF = (window.WF = { S: {}, charts: [], sel: null });
  const MINUS = '\u2212';
  const sg = (s) => s.replace(/-/g, MINUS);
  const F = (spec) => (x) => (Number.isFinite(x) ? sg(d3.format(spec)(x)) : '—');
  WF.fmt = {
    f0: F('.0f'), f1: F('.1f'), f2: F('.2f'), f3: F('.3f'), f4: F('.4f'), f5: F('.5f'),
    s2: F('+.2f'), s3: F('+.3f'), s4: F('+.4f'),
    pc0: F('.0%'), pc1: F('.1%'), pc2: F('.2%'), sp1: F('+.1%'), sp2: F('+.2%'),
    int: F(',.0f'),
    pv: (p) => (!Number.isFinite(p) ? '—' : p < 0.001 ? '<0.001' : p < 0.01 ? d3.format('.4f')(p) : d3.format('.3f')(p)),
  };
  WF.minus = sg;

  // ---------- typed rows ----------
  const cache = new WeakMap();
  function convert(rows) {
    if (!rows.length) return [];
    const cols = Object.keys(rows[0]);
    const isNum = {};
    cols.forEach((c) => {
      let ok = true, seen = 0;
      for (let i = 0; i < rows.length && seen < 80; i++) {
        const v = rows[i][c];
        if (v === '' || v == null) continue;
        seen++;
        if (typeof v !== 'number' && !(String(v).trim() !== '' && isFinite(Number(v)))) { ok = false; break; }
      }
      isNum[c] = ok && seen > 0;
    });
    return rows.map((r) => {
      const o = {};
      cols.forEach((c) => {
        const v = r[c];
        if (isNum[c]) o[c] = v === '' || v == null ? NaN : Number(v);
        else if (v === 'TRUE' || v === true) o[c] = true;
        else if (v === 'FALSE' || v === false) o[c] = false;
        else o[c] = v;
      });
      return o;
    });
  }
  WF.rows = (id) => {
    const r = dash.data(id);
    if (r.status !== 'ok' || !Array.isArray(r.data)) return null;
    let t = cache.get(r.data);
    if (!t) { t = convert(r.data); cache.set(r.data, t); }
    return t;
  };
  WF.pt = d3.utcParse('%Y-%m-%d %H:%M:%S');
  WF.pd = d3.utcParse('%Y-%m-%d');
  WF.C = () => ({
    iem: dash.colors[0], fut: dash.colors[1], kal: dash.colors[2], c4: dash.colors[3], c5: dash.colors[4],
    mute: 'var(--cds-chart-muted)', bad: 'var(--cds-chart-status-critical)', ref: 'var(--cds-chart-reference)',
    grid: 'var(--cds-chart-grid)', axis: 'var(--cds-chart-axis)', fg: 'var(--color-fg)', fgm: 'var(--color-fg-muted)',
  });
  WF.kr = () => {
    const rows = WF.rows('key_results');
    if (!rows) return null;
    if (!rows.__m) { const m = new Map(); rows.forEach((r) => m.set(r.id, r)); Object.defineProperty(rows, '__m', { value: m }); }
    return rows.__m;
  };
  WF.kv = (id) => { const m = WF.kr(); const r = m && m.get(id); return r ? r.R_value : NaN; };

  // ---------- {{id|fmt}} tokens -> marked placeholders ----------
  WF.hydrate = () => {
    const re = /\{\{([^|}]+)\|(\w+)\}\}/g;
    document.querySelectorAll('.wf .prose').forEach((root) => {
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      const nodes = [];
      while (w.nextNode()) if (w.currentNode.nodeValue.indexOf('{{') >= 0) nodes.push(w.currentNode);
      nodes.forEach((n) => {
        const s = n.nodeValue; const frag = document.createDocumentFragment(); let last = 0, m;
        re.lastIndex = 0;
        while ((m = re.exec(s))) {
          if (m.index > last) frag.appendChild(document.createTextNode(s.slice(last, m.index)));
          const b = document.createElement('b');
          b.className = 'n'; b.setAttribute('data-source', 'key_results'); b.setAttribute('data-field', 'R_value');
          b.setAttribute('data-where', 'id=' + encodeURIComponent(m[1])); b.setAttribute('data-fmt', m[2]); b.textContent = '—';
          frag.appendChild(b); last = m.index + m[0].length;
        }
        if (last < s.length) frag.appendChild(document.createTextNode(s.slice(last)));
        n.parentNode.replaceChild(frag, n);
      });
    });
  };
  WF.fill = () => {
    const m = WF.kr();
    document.querySelectorAll('.wf .n[data-fmt]').forEach((el) => {
      if (!m) { el.textContent = '—'; return; }
      const id = decodeURIComponent((el.getAttribute('data-where') || '').slice(3));
      const row = m.get(id); const f = WF.fmt[el.getAttribute('data-fmt')];
      el.textContent = row && f ? f(row.R_value) : '—';
    });
  };

  // ---------- tooltip ----------
  let tipEl;
  WF.tipShow = (ev, head, lines) => {
    const host = document.querySelector('.wf');
    if (!tipEl) { tipEl = document.createElement('div'); tipEl.className = 'wf-tip'; host.appendChild(tipEl); }
    tipEl.replaceChildren();
    if (head) { const h = document.createElement('div'); h.className = 'wf-tip-h'; h.textContent = head; tipEl.appendChild(h); }
    (lines || []).forEach((l) => {
      const r = document.createElement('div'); r.className = 'wf-tip-r';
      if (l.c) { const i = document.createElement('i'); i.style.background = l.c; r.appendChild(i); }
      r.appendChild(document.createTextNode(l.t)); tipEl.appendChild(r);
    });
    tipEl.style.display = 'block';
    const hb = host.getBoundingClientRect(); const tw = tipEl.offsetWidth, th = tipEl.offsetHeight;
    let x = ev.clientX - hb.left + 14, y = ev.clientY - hb.top + 14;
    if (x + tw > hb.width - 4) x = ev.clientX - hb.left - tw - 14;
    if (x < 4) x = 4;
    if (ev.clientY + th + 20 > window.innerHeight) y = ev.clientY - hb.top - th - 14;
    tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
  };
  WF.tipHide = () => { if (tipEl) tipEl.style.display = 'none'; };
  WF.hover = (sel, fn) => sel.on('mousemove touchmove', (ev, d) => { const r = fn(d); if (r) WF.tipShow(ev.touches ? ev.touches[0] : ev, r.h, r.l); }).on('mouseleave touchend', WF.tipHide);

  // ---------- chart engine ----------
  WF.chart = (sel, draw) => {
    const el = typeof sel === 'string' ? document.querySelector(sel) : sel;
    if (!el) return null;
    const c = { el, draw, deps: (el.getAttribute('data-source') || '').split(/\s+/).filter(Boolean), refs: [], w: 0, state: '' };
    el.classList.add('dash-skeleton'); WF.charts.push(c); return c;
  };
  WF.fail = (el) => {
    el.classList.remove('dash-skeleton'); el.replaceChildren();
    const d = document.createElement('div'); d.className = 'wf-fail'; const i = document.createElement('i'); const s = document.createElement('span'); s.textContent = 'Failed to load';
    d.appendChild(i); d.appendChild(s); el.appendChild(d);
  };
  function run(c, force) {
    const el = c.el;
    const ds = c.deps.map((id) => dash.data(id));
    if (ds.some((d) => ['error', 'connect', 'declined', 'missing'].includes(d.status))) { if (c.state !== 'fail') { WF.fail(el); c.state = 'fail'; c.refs = []; } return; }
    if (ds.some((d) => d.status !== 'ok')) return;
    const w = Math.round(el.clientWidth);
    if (w < 40) return;
    const refs = ds.map((d) => d.data);
    const same = c.state === 'ok' && c.w === w && c.refs.length === refs.length && refs.every((r, i) => r === c.refs[i]);
    if (same && !force) return;
    c.refs = refs; c.w = w; c.state = 'ok';
    el.classList.remove('dash-skeleton');
    try {
      if (!same) { el.replaceChildren(); el.__mode = null; }
      c.draw(el, w, !same);
    } catch (e) { console.error(el.id, e); WF.fail(el); c.state = 'fail'; }
  }
  WF.drawAll = () => WF.charts.forEach((c) => run(c, false));
  WF.redraw = (el) => { const c = WF.charts.find((x) => x.el === el || x.el.id === el); if (c) run(c, true); };

  // ---------- scrolly ----------
  WF.scrolly = (chapsId, onStep) => {
    const root = document.getElementById(chapsId);
    if (!root) return;
    const chaps = Array.from(root.querySelectorAll('.chap'));
    const io = new IntersectionObserver((es) => {
      es.forEach((e) => { if (e.isIntersecting) { chaps.forEach((c) => c.classList.toggle('on', c === e.target)); onStep(+e.target.getAttribute('data-step')); } });
    }, { root: null, rootMargin: '-42% 0px -42% 0px', threshold: 0 });
    chaps.forEach((c) => io.observe(c));
    if (chaps[0]) chaps[0].classList.add('on');
  };

  // ---------- svg helpers ----------
  WF.base = (el, w, h, m) => {
    m = Object.assign({ t: 14, r: 18, b: 40, l: 52 }, m || {});
    const W = Math.max(300, w);
    const svg = d3.select(el).append('svg').attr('viewBox', `0 0 ${W} ${h}`).attr('width', '100%').attr('role', 'img').style('display', 'block').style('overflow', 'visible');
    const g = svg.append('g').attr('transform', `translate(${m.l},${m.t})`);
    return { svg, g, W, H: h, iw: W - m.l - m.r, ih: h - m.t - m.b, m };
  };
  WF.h = (w, f, lo, hi) => Math.round(Math.max(lo || 240, Math.min(hi || 420, w * (f || 0.6))));
  const styleAx = (a) => {
    a.attr('font-size', null).attr('font-family', null);
    a.selectAll('text').style('fill', 'var(--color-fg-muted)').style('font-size', '11px');
    a.selectAll('.domain').style('stroke', 'var(--cds-chart-axis)'); a.selectAll('.tick line').style('stroke', 'var(--cds-chart-axis)');
    return a;
  };
  WF.axX = (g, sc, ih, o = {}) => {
    const ax = d3.axisBottom(sc); if (o.n) ax.ticks(o.n); if (o.tf) ax.tickFormat(o.tf); if (o.vals) ax.tickValues(o.vals); ax.tickSizeOuter(0);
    return styleAx(g.append('g').attr('transform', `translate(0,${ih})`).call(ax));
  };
  WF.axY = (g, sc, iw, o = {}) => {
    const ax = d3.axisLeft(sc); if (o.n) ax.ticks(o.n); if (o.tf) ax.tickFormat(o.tf); if (o.vals) ax.tickValues(o.vals); ax.tickSizeOuter(0); if (o.grid) ax.tickSize(-iw);
    const a = styleAx(g.append('g').call(ax));
    if (o.grid) { a.selectAll('.tick line').style('stroke', 'var(--cds-chart-grid)'); a.select('.domain').remove(); }
    return a;
  };
  WF.lab = (g, x, y, s, o = {}) => g.append('text').attr('x', x).attr('y', y).attr('text-anchor', o.a || 'start').attr('dominant-baseline', o.v || 'auto')
    .style('fill', o.fill || 'var(--color-fg-muted)').style('font-size', (o.s || 11) + 'px').style('font-weight', o.w || 400).style('pointer-events', 'none').text(s);
  WF.xT = (b, s) => WF.lab(b.g, b.iw / 2, b.ih + b.m.b - 6, s, { a: 'middle' });
  WF.yT = (b, s) => b.g.append('text').attr('transform', `translate(${-b.m.l + 12},${b.ih / 2}) rotate(-90)`).attr('text-anchor', 'middle').style('fill', 'var(--color-fg-muted)').style('font-size', '11px').text(s);
  WF.hline = (g, y, x0, x1, o = {}) => g.append('line').attr('x1', x0).attr('x2', x1).attr('y1', y).attr('y2', y).style('stroke', o.c || 'var(--cds-chart-reference)').attr('stroke-width', o.w || 1).attr('stroke-dasharray', o.d || null);
  WF.vline = (g, x, y0, y1, o = {}) => g.append('line').attr('x1', x).attr('x2', x).attr('y1', y0).attr('y2', y1).style('stroke', o.c || 'var(--cds-chart-reference)').attr('stroke-width', o.w || 1).attr('stroke-dasharray', o.d || null);
  WF.chips = (el, opts, cur, cb) => {
    el.replaceChildren();
    opts.forEach((o) => {
      const b = document.createElement('button'); b.type = 'button'; b.className = 'chip' + (o.v === cur ? ' on' : ''); b.textContent = o.t;
      b.addEventListener('click', () => cb(o.v)); el.appendChild(b);
    });
  };
  WF.legend = (el, items) => {
    el.replaceChildren();
    const d = document.createElement('div'); d.className = 'legend';
    items.forEach((it) => { const s = document.createElement('span'); const i = document.createElement('i'); i.style.background = it.c; s.appendChild(i); s.appendChild(document.createTextNode(it.t)); d.appendChild(s); });
    el.appendChild(d);
  };

  // ---------- statistics ----------
  function lgam(z) {
    const c = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
    let y = z, t = z + 5.5; t -= (z + 0.5) * Math.log(t); let s = 1.000000000190015;
    for (let j = 0; j < 6; j++) s += c[j] / ++y;
    return -t + Math.log((2.5066282746310005 * s) / z);
  }
  function betacf(a, b, x) {
    const FP = 1e-300; const qab = a + b, qap = a + 1, qam = a - 1; let c = 1, d = 1 - (qab * x) / qap;
    if (Math.abs(d) < FP) d = FP; d = 1 / d; let h = d;
    for (let m = 1; m <= 200; m++) {
      const m2 = 2 * m; let aa = (m * (b - m) * x) / ((qam + m2) * (a + m2));
      d = 1 + aa * d; if (Math.abs(d) < FP) d = FP; c = 1 + aa / c; if (Math.abs(c) < FP) c = FP; d = 1 / d; h *= d * c;
      aa = (-(a + m) * (qab + m) * x) / ((a + m2) * (qap + m2));
      d = 1 + aa * d; if (Math.abs(d) < FP) d = FP; c = 1 + aa / c; if (Math.abs(c) < FP) c = FP; d = 1 / d;
      const del = d * c; h *= del; if (Math.abs(del - 1) < 3e-12) break;
    }
    return h;
  }
  function ibeta(x, a, b) {
    if (x <= 0) return 0; if (x >= 1) return 1;
    const bt = Math.exp(lgam(a + b) - lgam(a) - lgam(b) + a * Math.log(x) + b * Math.log(1 - x));
    return x < (a + 1) / (a + b + 2) ? (bt * betacf(a, b, x)) / a : 1 - (bt * betacf(b, a, 1 - x)) / b;
  }
  WF.tp = (t, df) => ibeta(df / (df + t * t), df / 2, 0.5); // two-sided p of a t statistic
  WF.stats = (xs) => {
    const n = xs.length; if (n < 3) return { n, mean: NaN, sd: NaN, t: NaN, p: NaN };
    const mean = d3.mean(xs), sd = d3.deviation(xs), t = mean / (sd / Math.sqrt(n));
    return { n, mean, sd, t, p: WF.tp(t, n - 1) };
  };
  WF.ols = (pts) => {
    const n = pts.length; if (n < 3) return null;
    const mx = d3.mean(pts, (p) => p.x), my = d3.mean(pts, (p) => p.y);
    const sxx = d3.sum(pts, (p) => (p.x - mx) ** 2); if (!sxx) return null;
    const b = d3.sum(pts, (p) => (p.x - mx) * (p.y - my)) / sxx; return { b, a: my - b * mx };
  };

  // meeting selection shared across charts
  WF.selectMeeting = (date, scroll) => {
    WF.sel = date;
    const s = document.getElementById('mx-sel'); if (s) s.value = date;
    ['c-mx', 'c-sc', 'c-gt', 'c-gm', 'c-rel'].forEach((id) => WF.redraw(id));
    if (scroll) { const c = document.getElementById('c-mx'); if (c) c.closest('.card').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  };
})();
