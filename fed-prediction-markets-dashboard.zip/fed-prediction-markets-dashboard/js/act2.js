(function () {
  const S = (WF.S.early = { step: 0, ep: '2025-12', test: '2025-12|FUT_to_K', brush: {}, ml: '2025-12' });
  const $ = (id) => document.getElementById(id);
  const EPL = { '2025-09': 'September 2025', '2025-12': 'December 2025' };
  const TESTS = { '2025-09|FUT_to_K': 'Sep \u00b7 futures \u2192 Kalshi', '2025-09|K_to_FUT': 'Sep \u00b7 Kalshi \u2192 futures', '2025-12|FUT_to_K': 'Dec \u00b7 futures \u2192 Kalshi', '2025-12|K_to_FUT': 'Dec \u00b7 Kalshi \u2192 futures' };
  const TITLES = [
    ['Pass-through of a futures revision into IEM', 'Coefficient on a 1bp futures revision. Full pass-through would be 4. Bars: estimates; whiskers: 95% intervals.'],
    ['The same coefficient under stricter inference', 'Raw p-value (circle) and Holm-adjusted p-value (diamond) for the next-day coefficient. Dashed: 5%.'],
    ['Joint Granger tests by lag length', 'Common sample. Ring: the lag order BIC selects. Dashed: 5%.'],
    ['The same coefficient in three eras', 'One-lag futures-to-IEM coefficient, 95% cluster-robust intervals. Dashed: the full-sample estimate.'],
    ['Kalshi and futures, 15 minutes at a time', 'Expected policy change each market implies. Ticks: non-zero futures revisions. Drag the lower strip to zoom.'],
    ['Where does the observed statistic fall in its null?', 'Permutation distribution of |t| for the cross-lag coefficient (futures timing shifted within blocks).'],
    ['A handful of points carry the coefficient', 'Kalshi revision against the previous futures revision (15-minute). Line: fit through the non-zero revisions.'],
  ];
  const legendTop = (el, items) => { const d = document.createElement('div'); el.appendChild(d); WF.legend(d, items); };
  const p3 = (p) => WF.fmt.pv(p);

  // ---- 0: pass-through ----
  function bPass(el, w) {
    const C = WF.C(), P = WF.rows('passthrough'), H = WF.h(w, 0.5, 240, 330), b = WF.base(el, w, H, { l: Math.min(150, w * 0.3), b: 44, t: 10 });
    const FULL = 4; // K = 4E: complete next-day pass-through of 1bp
    const rows = [{ k: 'Full pass-through', v: FULL, lo: FULL, hi: FULL, sh: 1, c: C.mute }, { k: 'Same day', v: P[0].coefficient, lo: P[0].coefficient - 1.96 * P[0].cluster_se, hi: P[0].coefficient + 1.96 * P[0].cluster_se, sh: P[0].share_of_full_pass_through, c: C.kal }, { k: 'Next day (pre-specified)', v: P[1].coefficient, lo: P[1].coefficient - 1.96 * P[1].cluster_se, hi: P[1].coefficient + 1.96 * P[1].cluster_se, sh: P[1].share_of_full_pass_through, c: C.fut }];
    const x = d3.scaleLinear([Math.min(-0.3, d3.min(rows, (d) => d.lo) - 0.1), FULL + 0.4], [0, b.iw]), y = d3.scaleBand(rows.map((d) => d.k), [0, b.ih]).padding(0.35);
    WF.axX(b.g, x, b.ih, { n: 6, tf: WF.fmt.f1 }); WF.axY(b.g, y, b.iw, {}); WF.xT(b, 'Coefficient on a 1bp futures revision (IEM score points)');
    WF.vline(b.g, x(0), 0, b.ih, { c: 'var(--cds-chart-axis)' });
    rows.forEach((d) => {
      const bar = b.g.append('rect').attr('x', x(Math.min(0, d.v))).attr('width', Math.abs(x(d.v) - x(0))).attr('y', y(d.k)).attr('height', y.bandwidth()).attr('rx', 4).style('fill', d.c);
      if (d.k !== 'Full pass-through') { WF.hline(b.g, y(d.k) + y.bandwidth() / 2, x(d.lo), x(d.hi), { c: C.fg, w: 1.6 }); WF.vline(b.g, x(d.lo), y(d.k) + y.bandwidth() * 0.3, y(d.k) + y.bandwidth() * 0.7, { c: C.fg }); WF.vline(b.g, x(d.hi), y(d.k) + y.bandwidth() * 0.3, y(d.k) + y.bandwidth() * 0.7, { c: C.fg }); }
      WF.lab(b.g, Math.max(x(d.hi), x(d.v)) + 8, y(d.k) + y.bandwidth() / 2, d.k === 'Full pass-through' ? WF.fmt.f1(d.v) : WF.fmt.f2(d.v) + '  (' + WF.fmt.pc1(d.sh) + ' of full)', { v: 'middle', fill: 'var(--color-fg)', w: 600 });
      WF.hover(bar, () => ({ h: d.k, l: [{ t: 'Coefficient ' + WF.fmt.f3(d.v) }, { t: WF.fmt.pc1(d.sh) + ' of full pass-through' }] }));
    });
    return function upd() {};
  }

  // ---- 1: inference ladder ----
  function bInfer(el, w) {
    const C = WF.C(), R = WF.rows('inference_ladder'), H = WF.h(w, 0.55, 260, 350), b = WF.base(el, w, H, { l: Math.min(200, w * 0.4), b: 44, t: 24 });
    legendTop(el, [{ c: C.fut, t: 'Raw p-value' }, { c: C.fg, t: '\u25c6 Holm-adjusted p' }]);
    const x = d3.scaleLog([0.01, 1], [0, b.iw]), y = d3.scaleBand(R.map((d) => d.label), [0, b.ih]).padding(0.4);
    WF.axX(b.g, x, b.ih, { vals: [0.01, 0.03, 0.05, 0.1, 0.3, 1], tf: (d) => d3.format('~g')(d) }); WF.axY(b.g, y, b.iw, {}); WF.xT(b, 'p-value (log scale)');
    WF.vline(b.g, x(0.05), 0, b.ih, { c: C.bad, d: '4 3' }); WF.lab(b.g, x(0.05) + 4, -8, '5%', { fill: C.bad });
    R.forEach((d) => {
      const cy = y(d.label) + y.bandwidth() / 2;
      WF.hline(b.g, cy, x(Math.max(0.01, d.p)), x(Math.max(0.01, d.holm_p)), { c: C.grid || 'var(--cds-chart-grid)', w: 2 });
      const c1 = b.g.append('circle').attr('cx', x(Math.max(0.01, d.p))).attr('cy', cy).attr('r', 6).style('fill', C.fut);
      const c2 = b.g.append('path').attr('d', d3.symbol(d3.symbolDiamond, 110)()).attr('transform', `translate(${x(Math.max(0.01, d.holm_p))},${cy})`).style('fill', C.fg);
      WF.hover(c1, () => ({ h: d.label, l: [{ c: C.fut, t: 'Raw p ' + p3(d.p) }, { t: 'SE ' + WF.fmt.f4(d.se) + ', df ' + WF.fmt.f1(d.df) }] })); WF.hover(c2, () => ({ h: d.label, l: [{ t: 'Holm-adjusted p ' + p3(d.holm_p) }] }));
      if (d.df < 10) WF.lab(b.g, x(d.holm_p) + 12, cy, 'df \u2248 ' + WF.fmt.f1(d.df) + ': about four effective clusters', { v: 'middle', fill: 'var(--color-fg)' });
    });
    return function upd() {};
  }

  // ---- 2: lag grid ----
  function bLags(el, w) {
    const C = WF.C(), R = WF.rows('hist_lag'), H = WF.h(w, 0.6, 260, 360), b = WF.base(el, w, H, { l: 52, b: 44, t: 14 });
    legendTop(el, [{ c: C.fut, t: 'Futures \u2192 IEM' }, { c: C.iem, t: 'IEM \u2192 futures' }, { c: C.fg, t: '\u25cb lag chosen by BIC' }]);
    const x = d3.scaleLinear([0.7, 3.3], [0, b.iw]), y = d3.scaleLog([0.004, 1.3], [b.ih, 0]);
    WF.axX(b.g, x, b.ih, { vals: [1, 2, 3], tf: d3.format('d') }); WF.axY(b.g, y, b.iw, { grid: true, vals: [0.005, 0.01, 0.05, 0.1, 0.5, 1], tf: (d) => d3.format('~g')(d) });
    WF.xT(b, 'Lag order'); WF.yT(b, 'Joint Wald p-value (log scale)'); WF.hline(b.g, y(0.05), 0, b.iw, { c: C.bad, d: '4 3' }); WF.lab(b.g, b.iw - 2, y(0.05) - 5, '5%', { a: 'end', fill: C.bad });
    [['FUT_to_IEM', C.fut, 'Futures \u2192 IEM'], ['IEM_to_FUT', C.iem, 'IEM \u2192 futures']].forEach(([dir, col, nm]) => {
      const r = R.filter((d) => d.direction === dir).sort((a, c) => a.lag_order - c.lag_order), best = r.reduce((a, c) => (c.BIC < a.BIC ? c : a));
      b.g.append('path').attr('d', d3.line().x((d) => x(d.lag_order)).y((d) => y(d.joint_p))(r)).style('fill', 'none').style('stroke', col).attr('stroke-width', 2.4);
      const c = b.g.selectAll('.l' + dir).data(r).join('circle').attr('class', 'l' + dir).attr('cx', (d) => x(d.lag_order)).attr('cy', (d) => y(d.joint_p)).attr('r', 5.5).style('fill', col);
      b.g.append('circle').attr('cx', x(best.lag_order)).attr('cy', y(best.joint_p)).attr('r', 10).style('fill', 'none').style('stroke', C.fg).attr('stroke-width', 1.8);
      b.g.selectAll('.t' + dir).data(r).join('text').attr('class', 't' + dir).attr('x', (d) => x(d.lag_order)).attr('y', (d) => y(d.joint_p) + (dir === 'FUT_to_IEM' ? 20 : -12)).attr('text-anchor', 'middle').style('fill', col).style('font-size', '11px').style('font-weight', 600).text((d) => p3(d.joint_p));
      WF.hover(c, (d) => ({ h: nm + ' \u00b7 ' + d.lag_order + ' lag(s)', l: [{ t: 'Joint p ' + p3(d.joint_p) }, { t: d.n + ' rows, ' + d.meetings + ' meetings' }] }));
    });
    return function upd() {};
  }

  // ---- 3: eras ----
  function bEra(el, w) {
    const C = WF.C(), E = WF.rows('era_beta'), P = WF.rows('passthrough'), H = WF.h(w, 0.5, 240, 330), b = WF.base(el, w, H, { l: 96, b: 44, t: 14 });
    const base = P[1].coefficient, lo = d3.min(E, (d) => d.beta - 1.96 * d.se) - 0.1, hi = d3.max(E, (d) => d.beta + 1.96 * d.se) + 0.1;
    const x = d3.scaleLinear([Math.min(lo, -0.1), hi], [0, b.iw]), y = d3.scaleBand(E.map((d) => d.era), [0, b.ih]).padding(0.5);
    WF.axX(b.g, x, b.ih, { n: 6, tf: WF.fmt.f1 }); WF.axY(b.g, y, b.iw, {}); WF.xT(b, 'Coefficient on the lagged futures revision');
    WF.vline(b.g, x(0), 0, b.ih, { c: 'var(--cds-chart-axis)' }); WF.vline(b.g, x(base), 0, b.ih, { c: C.fg, d: '5 4' }); WF.lab(b.g, x(base) + 4, -3, 'full sample ' + WF.fmt.f2(base), { fill: 'var(--color-fg)' });
    E.forEach((d) => {
      const cy = y(d.era) + y.bandwidth() / 2;
      WF.hline(b.g, cy, x(d.beta - 1.96 * d.se), x(d.beta + 1.96 * d.se), { c: C.fut, w: 3 });
      const c = b.g.append('circle').attr('cx', x(d.beta)).attr('cy', cy).attr('r', 7).style('fill', C.fut).style('stroke', 'var(--color-bg)').attr('stroke-width', 2);
      WF.lab(b.g, x(d.beta), cy - 14, WF.fmt.f2(d.beta), { a: 'middle', fill: 'var(--color-fg)', w: 600 }); WF.lab(b.g, x(d.beta + 1.96 * d.se) + 8, cy, d.meetings + ' meetings', { v: 'middle' });
      WF.hover(c, () => ({ h: d.era, l: [{ t: 'Coefficient ' + WF.fmt.f3(d.beta) + ' (SE ' + WF.fmt.f3(d.se) + ')' }, { t: d.n + ' rows' }] }));
    });
    return function upd() {};
  }

  // ---- 4: modern 15-minute paths with brush ----
  function bModern(el, w) {
    const C = WF.C(), ep = S.ep, mine = (r) => r.meeting_id === ep;
    const paths = WF.rows('modern_paths').filter(mine).map((d) => ({ t: WF.pt(d.time), s: d.series, v: d.bp })).filter((d) => d.t);
    const rev = WF.rows('modern_revisions').filter((d) => mine(d) && d.kind === 'Non-zero').map((d) => ({ t: WF.pt(d.time), v: d.dF })).filter((d) => d.t);
    const sh = WF.rows('rev_shares').filter(mine), kal = paths.filter((d) => d.s.startsWith('Kalshi')), fut = paths.filter((d) => d.s.startsWith('Futures'));
    legendTop(el, [{ c: C.kal, t: 'Kalshi' }, { c: C.fut, t: 'Fed Funds futures' }]);
    const mainH = WF.h(w, 0.4, 210, 300), ctxH = 44, b = WF.base(el, w, mainH + 44 + ctxH + 22, { l: 48, b: 4, t: 22 });
    const full = d3.extent(paths, (d) => d.t), xc = d3.scaleUtc(full, [0, b.iw]), ym = d3.scaleLinear(d3.extent(paths, (d) => d.v), [mainH, 0]).nice(), yc = d3.scaleLinear(ym.domain(), [ctxH, 0]);
    const kShare = sh.find((d) => d.market === 'Kalshi'), fShare = sh.find((d) => d.market !== 'Kalshi');
    WF.lab(b.g, 0, -8, EPL[ep] + ': Kalshi moves in ' + WF.fmt.pc0(kShare ? kShare.share : NaN) + ' of 15-minute intervals, futures in ' + WF.fmt.pc0(fShare ? fShare.share : NaN) + ' (' + (fShare ? fShare.nonzero : '') + ' revisions)', { fill: 'var(--color-fg)', w: 600 });
    const cid = 'wfclip' + Math.floor(Math.random() * 1e9);
    b.svg.append('defs').append('clipPath').attr('id', cid).append('rect').attr('width', b.iw).attr('height', mainH);
    const M = b.g.append('g'), ctx = b.g.append('g').attr('transform', `translate(0,${mainH + 44})`);
    const stepLine = (xs, ys) => d3.line().curve(d3.curveStepAfter).x((d) => xs(d.t)).y((d) => ys(d.v));
    [[kal, C.kal], [fut, C.fut]].forEach(([d, c]) => ctx.append('path').attr('d', stepLine(xc, yc)(d)).style('fill', 'none').style('stroke', c).attr('stroke-width', 1).style('opacity', 0.8));
    ctx.append('g').attr('transform', `translate(0,${ctxH})`).call(d3.axisBottom(xc).ticks(5).tickFormat(d3.utcFormat('%b %-d')).tickSizeOuter(0)).call((a) => { a.attr('font-size', null).attr('font-family', null); a.selectAll('text').style('fill', 'var(--color-fg-muted)').style('font-size', '10px'); a.selectAll('line,path').style('stroke', 'var(--cds-chart-axis)'); });
    function main() {
      M.selectAll('*').remove();
      const dom = S.brush[ep] || full, xm = d3.scaleUtc(dom, [0, b.iw]);
      M.append('g').call((g) => WF.axY(g, ym, b.iw, { grid: true, n: 5, tf: d3.format('d') }));
      WF.axX(M, xm, mainH, { n: 6, tf: d3.utcFormat('%b %-d %H:%M') }); WF.yT(b, 'Expected change (bp)');
      const cl = M.append('g').attr('clip-path', `url(#${cid})`);
      [[kal, C.kal], [fut, C.fut]].forEach(([d, c]) => cl.append('path').attr('d', stepLine(xm, ym)(d)).style('fill', 'none').style('stroke', c).attr('stroke-width', 2).attr('stroke-linejoin', 'round'));
      cl.selectAll('line.rv').data(rev.filter((d) => d.t >= dom[0] && d.t <= dom[1])).join('line').attr('class', 'rv').attr('x1', (d) => xm(d.t)).attr('x2', (d) => xm(d.t)).attr('y1', mainH - 12).attr('y2', mainH).style('stroke', C.fut).attr('stroke-width', 2);
      const ov = M.append('rect').attr('width', b.iw).attr('height', mainH).style('fill', 'transparent'), bis = d3.bisector((d) => d.t).center;
      ov.on('mousemove touchmove', (e) => { const px = d3.pointer(e.touches ? e.touches[0] : e)[0], t = xm.invert(px), ik = bis(kal, t), jf = bis(fut, t); const k = kal[ik], f = fut[jf]; if (k && f) WF.tipShow(e.touches ? e.touches[0] : e, d3.utcFormat('%b %-d, %H:%M UTC')(k.t), [{ c: C.kal, t: 'Kalshi ' + WF.fmt.f2(k.v) + 'bp' }, { c: C.fut, t: 'Futures ' + WF.fmt.f2(f.v) + 'bp' }]); }).on('mouseleave', WF.tipHide);
    }
    const br = d3.brushX().extent([[0, 0], [b.iw, ctxH]]).on('brush end', (ev) => { if (!ev.sourceEvent) return; S.brush[ep] = ev.selection ? ev.selection.map(xc.invert) : null; main(); });
    const bg = ctx.append('g').call(br); if (S.brush[ep]) bg.call(br.move, S.brush[ep].map(xc));
    bg.selectAll('.selection').style('fill', 'var(--cds-chart-muted)').style('fill-opacity', 0.25).style('stroke', 'var(--cds-chart-axis)');
    main();
    return function upd() {};
  }

  // ---- 5: permutation null ----
  function bPerm(el, w) {
    const C = WF.C(), [mid, dir] = S.test.split('|'), nl = WF.rows('perm_null').filter((d) => d.meeting_id === mid && d.direction === dir).map((d) => d.abs_t), T = WF.rows('modern_tests').find((d) => d.meeting_id === mid && d.direction === dir);
    const H = WF.h(w, 0.58, 260, 370), b = WF.base(el, w, H, { l: 50, b: 44, t: 38 }), obs = T.observed_abs_t;
    const x = d3.scaleLinear([0, Math.max(d3.max(nl), obs) * 1.06], [0, b.iw]), bins = d3.bin().domain(x.domain()).thresholds(30)(nl), y = d3.scaleLinear([0, d3.max(bins, (d) => d.length)], [b.ih, 0]).nice();
    WF.axY(b.g, y, b.iw, { grid: true, n: 5 }); WF.axX(b.g, x, b.ih, { n: 6, tf: WF.fmt.f1 }); WF.xT(b, '|t| of the cross-lag coefficient under the null'); WF.yT(b, 'Permutations');
    const bars = b.g.selectAll('rect').data(bins).join('rect').attr('x', (d) => x(d.x0) + 0.5).attr('width', (d) => Math.max(0, x(d.x1) - x(d.x0) - 1)).attr('y', (d) => y(d.length)).attr('height', (d) => b.ih - y(d.length)).style('fill', (d) => (d.x0 >= obs ? C.bad : C.mute)).style('opacity', (d) => (d.x0 >= obs ? 0.85 : 0.55));
    WF.hover(bars, (d) => ({ h: '|t| from ' + WF.fmt.f2(d.x0) + ' to ' + WF.fmt.f2(d.x1), l: [{ t: d.length + ' of ' + nl.length + ' permutations' }] }));
    WF.vline(b.g, x(obs), -4, b.ih, { c: C.fg, w: 2 }); WF.lab(b.g, x(obs) + (x(obs) > b.iw * 0.7 ? -6 : 6), 8, 'observed ' + WF.fmt.f2(obs), { a: x(obs) > b.iw * 0.7 ? 'end' : 'start', fill: 'var(--color-fg)', w: 600 });
    WF.lab(b.g, 0, -24, TESTS[S.test] + ': coefficient ' + WF.fmt.s3(T.coefficient), { fill: 'var(--color-fg)', w: 600, s: 12 });
    WF.lab(b.g, 0, -8, 'Block-HAC p ' + p3(T.block_HAC_p) + ' (Holm ' + p3(T.holm_hac) + ')  \u00b7  Permutation p ' + p3(T.permutation_p_two_sided) + ' (Holm ' + p3(T.holm_perm) + ')');
    return function upd() {};
  }

  // ---- 6: scatter ----
  function bScatter(el, w) {
    const C = WF.C(), ep = S.ep, R = WF.rows('modern_scatter').filter((d) => d.meeting_id === ep), nz = R.filter((d) => d.nonzero === true), H = WF.h(w, 0.62, 260, 370);
    legendTop(el, [{ c: C.mute, t: 'Zero futures revision' }, { c: C.fut, t: 'Non-zero futures revision' }]);
    const b = WF.base(el, w, H, { l: 50, b: 44, t: 12 }), x = d3.scaleLinear(d3.extent(R, (d) => d.x), [0, b.iw]).nice(), y = d3.scaleLinear(d3.extent(R, (d) => d.y), [b.ih, 0]).nice();
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f1 }); WF.axX(b.g, x, b.ih, { n: 7, tf: WF.fmt.f1 }); WF.xT(b, 'Previous futures revision (bp)'); WF.yT(b, 'Kalshi revision (bp)'); WF.vline(b.g, x(0), 0, b.ih, { c: 'var(--cds-chart-axis)' });
    const dots = b.g.selectAll('circle').data(R).join('circle').attr('cx', (d) => x(d.x)).attr('cy', (d) => y(d.y)).attr('r', (d) => (d.nonzero ? 6 : 3)).style('fill', (d) => (d.nonzero ? C.fut : C.mute)).style('opacity', (d) => (d.nonzero ? 0.9 : 0.5));
    WF.hover(dots, (d) => ({ h: d3.utcFormat('%b %-d, %H:%M UTC')(WF.pt(d.time)), l: [{ t: 'Futures ' + WF.fmt.f2(d.x) + 'bp, then Kalshi ' + WF.fmt.f2(d.y) + 'bp' }] }));
    const f = WF.ols(nz.map((d) => ({ x: d.x, y: d.y })));
    if (f) { const xs = d3.extent(nz, (d) => d.x); b.g.append('line').attr('x1', x(xs[0])).attr('x2', x(xs[1])).attr('y1', y(f.a + f.b * xs[0])).attr('y2', y(f.a + f.b * xs[1])).style('stroke', C.fg).attr('stroke-width', 2); WF.lab(b.g, b.iw - 2, 8, nz.length + ' non-zero points; fitted slope ' + WF.fmt.f2(f.b), { a: 'end', fill: 'var(--color-fg)', w: 600 }); }
    return function upd() {};
  }

  function drawStage(el, w, fresh) {
    const key = S.step + '|' + S.ep + '|' + S.test;
    if (fresh || el.__mode !== key) { el.replaceChildren(); el.__mode = key; [bPass, bInfer, bLags, bEra, bModern, bPerm, bScatter][S.step](el, w); }
  }
  function ctlRender() {
    const c = $('ctl-early'); c.replaceChildren(); const el = $('c-early');
    if (S.step === 4 || S.step === 6) WF.chips(c, Object.keys(EPL).map((k) => ({ v: k, t: EPL[k] })), S.ep, (v) => { S.ep = v; ctlRender(); WF.redraw(el); });
    else if (S.step === 5) WF.chips(c, Object.keys(TESTS).map((k) => ({ v: k, t: TESTS[k] })), S.test, (v) => { S.test = v; ctlRender(); WF.redraw(el); });
  }
  function setStep(i) {
    if (i === S.step && $('ttl-early').textContent) return;
    S.step = i; $('ttl-early').textContent = TITLES[i][0]; $('note-early').textContent = TITLES[i][1]; ctlRender(); WF.redraw($('c-early'));
  }

  // ---------- explore ----------
  function drawHs(el, w) {
    const C = WF.C(), R = WF.rows('hist_scatter'), panels = Array.from(new Set(R.map((d) => d.panel))), wide = w > 640, pw = wide ? (w - 20) / 2 : w;
    const ext = d3.extent(R, (d) => d.y), ys = [Math.max(-14, ext[0]), Math.min(14, ext[1])], wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:20px'; el.appendChild(wrap);
    panels.forEach((p) => {
      const host = document.createElement('div'); host.style.width = pw + 'px'; wrap.appendChild(host);
      const rows = R.filter((d) => d.panel === p), H = WF.h(pw, 0.7, 240, 320), b = WF.base(host, pw, H, { l: 44, b: 42, t: 24 });
      const xe = d3.extent(rows, (d) => d.x), x = d3.scaleLinear([Math.max(-10, xe[0]), Math.min(10, xe[1])], [0, b.iw]).nice(), y = d3.scaleLinear(ys, [b.ih, 0]).nice();
      WF.axY(b.g, y, b.iw, { grid: true, n: 5 }); WF.axX(b.g, x, b.ih, { n: 6, tf: d3.format('d') }); WF.xT(b, 'Futures revision (bp, demeaned)'); WF.lab(b.g, 0, -9, p, { fill: 'var(--color-fg)', w: 600 });
      b.g.selectAll('circle.pt').data(rows.filter((d) => Math.abs(d.y) <= ys[1] + 5)).join('circle').attr('class', 'pt').attr('cx', (d) => x(d.x)).attr('cy', (d) => y(d.y)).attr('r', 2).style('fill', C.mute).style('opacity', 0.28);
      const f = WF.ols(rows); if (f) { const xs = x.domain(); b.g.append('line').attr('x1', x(xs[0])).attr('x2', x(xs[1])).attr('y1', y(f.a + f.b * xs[0])).attr('y2', y(f.a + f.b * xs[1])).style('stroke', C.fg).attr('stroke-width', 2); }
      const q = d3.range(0, 1.0001, 0.1).map((t) => d3.quantile(rows.map((d) => d.x).sort(d3.ascending), t)), bins = [];
      for (let i = 0; i < q.length - 1; i++) { const g = rows.filter((d) => d.x >= q[i] && (i === q.length - 2 ? d.x <= q[i + 1] : d.x < q[i + 1])); if (g.length) bins.push({ x: d3.mean(g, (d) => d.x), y: d3.mean(g, (d) => d.y), n: g.length }); }
      const dm = b.g.selectAll('circle.dm').data(bins).join('circle').attr('class', 'dm').attr('cx', (d) => x(d.x)).attr('cy', (d) => y(d.y)).attr('r', 5).style('fill', C.fut).style('stroke', 'var(--color-bg)');
      WF.hover(dm, (d) => ({ h: 'Decile mean', l: [{ t: 'x ' + WF.fmt.f2(d.x) + ', y ' + WF.fmt.f2(d.y) }, { t: d.n + ' observations' }] }));
    });
  }
  function drawCcf(el, w) {
    const C = WF.C(), R = WF.rows('ccf'), H = WF.h(w, 0.6, 250, 340);
    legendTop(el, [{ c: C.fut, t: 'Futures earlier (k > 0)' }, { c: C.iem, t: 'IEM earlier (k < 0)' }, { c: C.mute, t: 'Same day' }]);
    const b = WF.base(el, w, H, { l: 48, b: 42, t: 10 }), x = d3.scaleBand(R.map((d) => d.lag), [0, b.iw]).padding(0.25), y = d3.scaleLinear([Math.min(-0.15, d3.min(R, (d) => d.corr - d.ci)), Math.max(0.33, d3.max(R, (d) => d.corr + d.ci))], [b.ih, 0]).nice();
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f2 }); WF.axX(b.g, x, b.ih, {}); WF.xT(b, 'Lag k (days)'); WF.yT(b, 'Correlation'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
    const bars = b.g.selectAll('rect').data(R).join('rect').attr('x', (d) => x(d.lag)).attr('width', x.bandwidth()).attr('y', (d) => y(Math.max(0, d.corr))).attr('height', (d) => Math.abs(y(d.corr) - y(0))).attr('rx', 2).style('fill', (d) => (d.lag > 0 ? C.fut : d.lag < 0 ? C.iem : C.mute));
    R.forEach((d) => { const cx = x(d.lag) + x.bandwidth() / 2; WF.vline(b.g, cx, y(d.corr - d.ci), y(d.corr + d.ci), { c: C.fg, w: 1.2 }); });
    WF.hover(bars, (d) => ({ h: 'Lag ' + d.lag, l: [{ t: 'Correlation ' + WF.fmt.f3(d.corr) + ' \u00b1 ' + WF.fmt.f3(d.ci) }, { t: d.n + ' pairs' }] }));
  }
  function drawLoo(el, w) {
    const C = WF.C(), R = WF.rows('loo_beta').slice().sort((a, c) => a.beta - c.beta), I = WF.rows('inference_ladder').find((d) => d.correction === 'successor_CR1_k2'), H = WF.h(w, 0.6, 250, 340);
    const b = WF.base(el, w, H, { l: 48, b: 40, t: 10 }), x = d3.scaleLinear([0, R.length + 1], [0, b.iw]), y = d3.scaleLinear([Math.min(0, d3.min(R, (d) => d.beta), I.beta - 1.96 * I.se), Math.max(d3.max(R, (d) => d.beta), I.beta + 1.96 * I.se)], [b.ih, 0]).nice();
    b.g.append('rect').attr('width', b.iw).attr('y', y(I.beta + 1.96 * I.se)).attr('height', y(I.beta - 1.96 * I.se) - y(I.beta + 1.96 * I.se)).style('fill', 'var(--cds-chart-muted)').style('opacity', 0.25);
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f2 }); WF.axX(b.g, x, b.ih, { n: 5, tf: d3.format('d') }); WF.xT(b, 'Meetings dropped one at a time, sorted'); WF.yT(b, 'One-lag coefficient'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' }); WF.hline(b.g, y(I.beta), 0, b.iw, { c: C.fg, d: '5 4' });
    const dots = b.g.selectAll('circle').data(R).join('circle').attr('cx', (d, i) => x(i + 1)).attr('cy', (d) => y(d.beta)).attr('r', 3.6).style('fill', C.fut).style('opacity', 0.85);
    WF.hover(dots, (d) => ({ h: 'Without meeting ' + d.meeting, l: [{ t: 'Coefficient ' + WF.fmt.f3(d.beta) }, { t: 'First observation ' + d.first_date }] }));
  }
  function drawMl(el, w) {
    const C = WF.C(), R = WF.rows('modern_lags').filter((d) => d.meeting_id === S.ml), H = WF.h(w, 0.72, 280, 380), b = WF.base(el, w, H, { l: 52, b: 40, t: 12 });
    const ctl = $('ctl-ml'); WF.chips(ctl, Object.keys(EPL).map((k) => ({ v: k, t: EPL[k] })), S.ml, (v) => { S.ml = v; WF.redraw(el); });
    legendTop(el, [{ c: C.fut, t: 'Futures \u2192 Kalshi' }, { c: C.kal, t: 'Kalshi \u2192 futures' }, { c: C.fg, t: '\u25cb BIC choice' }]);
    const gh = 70, mh = b.ih - gh - 28, x = d3.scaleLinear([0.7, 4.3], [0, b.iw]), y = d3.scaleLog([0.004, 1.3], [mh, 0]), best = R.reduce((a, c) => (c.BIC_sum < a.BIC_sum ? c : a));
    WF.axY(b.g, y, b.iw, { grid: true, vals: [0.005, 0.01, 0.05, 0.1, 0.5, 1], tf: (d) => d3.format('~g')(d) }); WF.axX(b.g, x, mh, { vals: [1, 2, 3, 4], tf: d3.format('d') }); WF.xT(b, 'Lag order'); WF.yT(b, 'Joint p-value (log)');
    WF.hline(b.g, y(0.05), 0, b.iw, { c: C.bad, d: '4 3' });
    [['FUT_to_K_p', C.fut, 'Futures \u2192 Kalshi'], ['K_to_FUT_p', C.kal, 'Kalshi \u2192 futures']].forEach(([f, col, nm]) => {
      b.g.append('path').attr('d', d3.line().x((d) => x(d.lag_order)).y((d) => y(d[f]))(R)).style('fill', 'none').style('stroke', col).attr('stroke-width', 2.2);
      const c = b.g.selectAll('.m' + f).data(R).join('circle').attr('class', 'm' + f).attr('cx', (d) => x(d.lag_order)).attr('cy', (d) => y(d[f])).attr('r', 4.5).style('fill', col);
      WF.hover(c, (d) => ({ h: nm + ' \u00b7 ' + d.lag_order + ' lag(s)', l: [{ t: 'Joint p ' + p3(d[f]) }, { t: d.n + ' blocks' }] }));
    });
    b.g.append('circle').attr('cx', x(best.lag_order)).attr('cy', y(best.FUT_to_K_p)).attr('r', 9).style('fill', 'none').style('stroke', C.fg).attr('stroke-width', 1.8);
    const G = b.g.append('g').attr('transform', `translate(0,${mh + 36})`); WF.lab(G, -4, -6, 'Residual Ljung\u2013Box p (red: below 5%)', { fill: 'var(--color-fg)', w: 600 });
    [['Kalshi_resid_LB10_p', 'Kalshi eq.'], ['Futures_resid_LB10_p', 'Futures eq.']].forEach(([f, nm], r) => {
      WF.lab(G, -6, r * 26 + 24, nm, { a: 'end', v: 'middle' });
      R.forEach((d) => { const cx = x(d.lag_order) - 26; G.append('rect').attr('x', cx).attr('y', r * 26 + 10).attr('width', 52).attr('height', 22).attr('rx', 4).style('fill', d[f] < 0.05 ? C.bad : 'var(--cds-chart-grid)').style('opacity', d[f] < 0.05 ? 0.75 : 1); WF.lab(G, cx + 26, r * 26 + 24, p3(d[f]), { a: 'middle', v: 'middle', fill: 'var(--color-fg)' }); });
    });
  }
  function drawRs(el, w) {
    const C = WF.C(), R = WF.rows('rev_shares'), H = WF.h(w, 0.6, 240, 320), eps = Array.from(new Set(R.map((d) => d.meeting_id))), mk = ['Kalshi', 'Fed Funds futures'];
    legendTop(el, [{ c: C.kal, t: 'Kalshi' }, { c: C.fut, t: 'Fed Funds futures' }]);
    const b = WF.base(el, w, H, { l: 48, b: 40, t: 14 }), x0 = d3.scaleBand(eps, [0, b.iw]).padding(0.3), x1 = d3.scaleBand(mk, [0, x0.bandwidth()]).padding(0.12), y = d3.scaleLinear([0, 0.7], [b.ih, 0]);
    WF.axY(b.g, y, b.iw, { grid: true, n: 5, tf: d3.format('.0%') }); WF.axX(b.g, x0, b.ih, { tf: (d) => EPL[d] || d }); WF.yT(b, 'Intervals with a non-zero revision');
    const bars = b.g.selectAll('rect').data(R).join('rect').attr('x', (d) => x0(d.meeting_id) + x1(d.market)).attr('width', x1.bandwidth()).attr('y', (d) => y(d.share)).attr('height', (d) => b.ih - y(d.share)).attr('rx', 3).style('fill', (d) => (d.market === 'Kalshi' ? C.kal : C.fut));
    b.g.selectAll('text.v').data(R).join('text').attr('class', 'v').attr('x', (d) => x0(d.meeting_id) + x1(d.market) + x1.bandwidth() / 2).attr('y', (d) => y(d.share) - 5).attr('text-anchor', 'middle').style('fill', 'var(--color-fg)').style('font-size', '11px').style('font-weight', 600).text((d) => WF.fmt.pc0(d.share));
    WF.hover(bars, (d) => ({ h: d.market + ' \u00b7 ' + (EPL[d.meeting_id] || d.meeting_id), l: [{ t: d.nonzero + ' of ' + d.intervals + ' intervals' }] }));
  }

  WF.chart('#c-early', drawStage); WF.chart('#c-hs', drawHs); WF.chart('#c-ccf', drawCcf); WF.chart('#c-loo', drawLoo); WF.chart('#c-ml', drawMl); WF.chart('#c-rs', drawRs);
  WF.scrolly('chaps-early', setStep);
  $('ttl-early').textContent = TITLES[0][0]; $('note-early').textContent = TITLES[0][1];
})();
