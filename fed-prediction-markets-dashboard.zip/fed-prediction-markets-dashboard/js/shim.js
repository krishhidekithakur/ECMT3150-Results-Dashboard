/* Minimal stand-in for the dashboard runtime: serves embedded CSV text as rows and re-runs callbacks on resize. */
(function () {
  function parseCSV(text) {
    const rows = []; let row = [], f = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += c; }
      else if (c === '"') q = true;
      else if (c === ',') { row.push(f); f = ''; }
      else if (c === '\n') { row.push(f); rows.push(row); row = []; f = ''; }
      else if (c !== '\r') f += c;
    }
    if (f.length || row.length) { row.push(f); rows.push(row); }
    const head = rows.shift() || [];
    return rows.filter((r) => r.length > 1 || r[0] !== '').map((r) => { const o = {}; head.forEach((h, i) => (o[h] = r[i] === undefined ? '' : r[i])); return o; });
  }
  const cache = {}, cbs = [];
  window.dash = {
    colors: ['var(--c0)', 'var(--c1)', 'var(--c2)', 'var(--c3)', 'var(--c4)', 'var(--c5)', 'var(--c6)', 'var(--c7)'],
    data(id) {
      const raw = window.WF_DATA && window.WF_DATA[id];
      if (raw == null) return { status: 'missing', data: [], message: 'no such dataset' };
      if (!cache[id]) cache[id] = parseCSV(raw);
      return { status: 'ok', data: cache[id], refreshing: false, meta: [] };
    },
    onData(fn) { cbs.push(fn); fn(); },
    setLink(name) { try { history.replaceState(null, '', '#' + name); } catch (e) {} },
    params() { return {}; }, setParams() {}, resetParams() {}, refresh() {},
  };
  let t; const again = () => { clearTimeout(t); t = setTimeout(() => cbs.forEach((f) => f()), 120); };
  window.addEventListener('resize', again); window.addEventListener('load', again);
})();
