(function () {
  const $ = (id) => document.getElementById(id);
  const legendTop = (el, items) => { const d = document.createElement('div'); el.appendChild(d); WF.legend(d, items); };
  const p3 = (p) => WF.fmt.pv(p);
  const MLAB = { 'Futures-inclusive logit': 'Futures + Kalshi history', 'Kalshi-only logit': 'Kalshi history only', 'Reversal rule': 'Reversal rule (no model)' };
  const CHN = { activity: 'Price-changing activity', direction: 'Hawkish direction', size: 'Step size' };

  // ================= ACT 3 =================
  const S3 = (WF.S.how = { step: 0 });
  const T3 = [
    ['Futures-response coefficients with 95% intervals', 'Real test (prior futures bar) against placebo (next bar). Zero means no effect. Each panel has its own scale.'],
    ['Held-out direction accuracy', 'Leave-one-meeting-out. Adding futures never improves on Kalshi history alone.'],
    ['How often consecutive Kalshi moves reverse', 'Each row is 20 consecutive price changes; filled dots reverse the previous move.'],
  ];
  function bForest(el, w) {
    const C = WF.C(), R = WF.rows('channel_tests'), chs = ['activity', 'direction', 'size'], ph = 96, H = ph * 3 + 56, b = WF.base(el, w, H, { l: 20, r: 120, b: 6, t: 10 });
    legendTop(el, [{ c: C.fut, t: 'Prior futures bar (real test)' }, { c: C.mute, t: 'Next futures bar (placebo)' }]);
    chs.forEach((ch, i) => {
      const rows = R.filter((d) => d.channel === ch), g = b.g.append('g').attr('transform', `translate(0,${i * (ph + 6)})`), ext = d3.extent(rows.flatMap((d) => [d.lo, d.hi, 0]));
      const x = d3.scaleLinear([ext[0] - 0.05 * (ext[1] - ext[0]), ext[1] + 0.05 * (ext[1] - ext[0])], [0, b.iw]), y = d3.scaleBand(['Prior futures bar (real test)', 'Next futures bar (placebo)'], [18, ph - 22]).padding(0.3);
      WF.lab(g, 0, 6, CHN[ch], { fill: 'var(--color-fg)', w: 600 }); WF.axX(g, x, ph - 20, { n: 5, tf: d3.format('.2f') }); WF.vline(g, x(0), 14, ph - 22, { c: C.fg, d: '4 3' });
      rows.forEach((d) => {
        const real = d.kind.startsWith('Prior'), cy = y(d.kind) + y.bandwidth() / 2, col = real ? C.fut : C.mute;
        WF.hline(g, cy, x(d.lo), x(d.hi), { c: col, w: 3 }); const c = g.append('circle').attr('cx', x(d.coef)).attr('cy', cy).attr('r', 6).style('fill', col).style('stroke', 'var(--color-bg)').attr('stroke-width', 2);
        WF.lab(g, b.iw + 10, cy, real ? 'Holm p ' + p3(d.holm) : 'placebo p ' + p3(d.p_raw), { v: 'middle', fill: 'var(--color-fg)', w: real ? 600 : 400 });
        WF.hover(c, () => ({ h: CHN[ch] + ' \u00b7 ' + d.kind, l: [{ t: 'Coefficient ' + WF.fmt.s3(d.coef) }, { t: '95% interval ' + WF.fmt.f3(d.lo) + ' to ' + WF.fmt.f3(d.hi) }, { t: d.n.toLocaleString('en') + ' observations' }] }));
      });
    });
  }
  function bAcc(el, w) {
    const C = WF.C(), R = WF.rows('heldout'), H = WF.h(w, 0.5, 240, 320), cols = { 'Futures-inclusive logit': C.fut, 'Kalshi-only logit': C.kal, 'Reversal rule': C.c4 };
    legendTop(el, Object.keys(MLAB).map((k) => ({ c: cols[k], t: MLAB[k] })));
    const b = WF.base(el, w, H, { l: 70, b: 44, t: 10 }), ms = Array.from(new Set(R.map((d) => d.heldout_meeting))), x = d3.scaleLinear([Math.floor(d3.min(R, (d) => d.accuracy) - 1), 100], [0, b.iw]), y = d3.scaleBand(ms, [0, b.ih]).padding(0.5);
    WF.axX(b.g, x, b.ih, { n: 6, tf: (d) => d + '%' }); WF.axY(b.g, y, b.iw, { grid: false }); WF.xT(b, 'Held-out accuracy');
    ms.forEach((m) => {
      const rows = R.filter((d) => d.heldout_meeting === m), cy = y(m) + y.bandwidth() / 2, e = d3.extent(rows, (d) => d.accuracy); WF.hline(b.g, cy, x(e[0]), x(e[1]), { c: 'var(--cds-chart-grid)', w: 6 });
      rows.forEach((d, i) => { const c = b.g.append('circle').attr('cx', x(d.accuracy)).attr('cy', cy + (i - 1) * 0.1).attr('r', 8 - i * 1.5).style('fill', cols[d.model]).style('opacity', 0.9).style('stroke', 'var(--color-bg)'); WF.hover(c, () => ({ h: m + ' \u00b7 ' + MLAB[d.model], l: [{ t: 'Accuracy ' + WF.fmt.f2(d.accuracy) + '%' }, { t: d.n.toLocaleString('en') + ' held-out events' }] })); });
    });
  }
  function bBounce(el, w) {
    const C = WF.C(), R = WF.rows('heldout').filter((d) => d.model === 'Reversal rule'), H = WF.h(w, 0.42, 220, 300), b = WF.base(el, w, H, { l: 70, b: 8, t: 10 });
    legendTop(el, [{ c: C.c4, t: 'Reverses the previous move' }, { c: C.mute, t: 'Continues in the same direction' }]);
    const y = d3.scaleBand(R.map((d) => d.heldout_meeting), [0, b.ih]).padding(0.25), r = Math.min(13, (b.iw - 90) / 20 / 2.2), step = Math.min(r * 2.5, (b.iw - 90) / 20);
    WF.axY(b.g, y, b.iw, {}).select('.domain').remove();
    R.forEach((d) => {
      const per = (d.accuracy / 100) * 20, cy = y(d.heldout_meeting) + y.bandwidth() / 2;
      for (let i = 0; i < 20; i++) b.g.append('circle').attr('cx', 12 + i * step).attr('cy', cy).attr('r', r).style('fill', i < Math.round(per) ? C.c4 : C.mute).style('opacity', i < Math.round(per) ? 1 : 0.55);
      const t = WF.lab(b.g, 12 + 20 * step + 4, cy, WF.fmt.f1(per) + ' / 20', { v: 'middle', fill: 'var(--color-fg)', w: 600 }); WF.hover(t.style('pointer-events', 'all'), () => ({ h: d.heldout_meeting, l: [{ t: WF.fmt.f2(d.accuracy) + '% of held-out moves reverse' }] }));
    });
  }
  function draw3(el, w, fresh) { if (fresh || el.__mode !== S3.step) { el.replaceChildren(); el.__mode = S3.step; [bForest, bAcc, bBounce][S3.step](el, w); } }
  function set3(i) { if (i === S3.step && $('ttl-how').textContent) return; S3.step = i; $('ttl-how').textContent = T3[i][0]; $('note-how').textContent = T3[i][1]; WF.redraw($('c-how')); }
  function drawHb(el, w) {
    const C = WF.C(), R = WF.rows('heldout').filter((d) => d.model !== 'Reversal rule'), ms = Array.from(new Set(R.map((d) => d.heldout_meeting))), mods = ['Futures-inclusive logit', 'Kalshi-only logit'], cols = { 'Futures-inclusive logit': C.fut, 'Kalshi-only logit': C.kal };
    legendTop(el, mods.map((k) => ({ c: cols[k], t: MLAB[k] })));
    const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:20px'; el.appendChild(wrap); const pw = w > 600 ? (w - 20) / 2 : w;
    [['brier', 'Brier score'], ['log_loss', 'Log loss']].forEach(([f, nm]) => {
      const host = document.createElement('div'); host.style.width = pw + 'px'; wrap.appendChild(host); const b = WF.base(host, pw, WF.h(pw, 0.62, 230, 300), { l: 48, b: 38, t: 22 });
      const x0 = d3.scaleBand(ms, [0, b.iw]).padding(0.25), x1 = d3.scaleBand(mods, [0, x0.bandwidth()]).padding(0.1), y = d3.scaleLinear([0, d3.max(R, (d) => d[f]) * 1.15], [b.ih, 0]);
      WF.axY(b.g, y, b.iw, { grid: true, n: 5, tf: f === 'brier' ? d3.format('.3f') : d3.format('.2f') }); WF.axX(b.g, x0, b.ih, {}); WF.lab(b.g, 0, -8, nm + ' (lower is better)', { fill: 'var(--color-fg)', w: 600 });
      const bars = b.g.selectAll('rect').data(R).join('rect').attr('x', (d) => x0(d.heldout_meeting) + x1(d.model)).attr('width', x1.bandwidth()).attr('y', (d) => y(d[f])).attr('height', (d) => b.ih - y(d[f])).attr('rx', 3).style('fill', (d) => cols[d.model]);
      WF.hover(bars, (d) => ({ h: d.heldout_meeting + ' \u00b7 ' + MLAB[d.model], l: [{ t: nm + ' ' + d3.format('.4f')(d[f]) }] }));
    });
  }

  // ================= ACT 4 =================
  const S4 = (WF.S.use = { step: 0, loss: 'QLIKE', mat: '2Y', view: 'bars', brush: {} });
  const T4 = [
    ['In-sample likelihood-ratio tests', 'p-value for adding the crowd terms to a model that already has calendar and futures terms. Dashed: 5%.'],
    ['Out-of-sample loss ratios', 'Loss with crowd terms divided by loss without. Below 1 favours the crowd. Labels: Diebold\u2013Mariano p.'],
    ['Cumulative loss difference', 'Announcement model minus plain GARCH, out of sample. Falling means the announcement model forecasts better.'],
    ['Announcement days, ranked', 'QLIKE difference on each FOMC announcement day (announcement model minus plain GARCH).'],
    ['Conditional volatility', 'Fitted daily standard deviation of yield changes. Red dots: announcement days. Drag the lower strip to zoom.'],
    ['Connectedness (exploratory)', 'Five-asset volatility system with the crowd variable as one node. Descriptive only.'],
  ];
  const MATS = ['2Y', '5Y', '10Y'], MATCH = { '2Y': '2-year', '5Y': '5-year', '10Y': '10-year' };
  function bLr(el, w) {
    const C = WF.C(), R = WF.rows('lr_tests'), H = WF.h(w, 0.55, 240, 330), b = WF.base(el, w, H, { l: 52, b: 40, t: 14 });
    legendTop(el, [{ c: C.kal, t: 'Crowd variance terms' }, { c: C.c4, t: 'Crowd entropy terms' }]);
    const x0 = d3.scaleBand(MATS, [0, b.iw]).padding(0.3), x1 = d3.scaleBand(['withV', 'withEntropy'], [0, x0.bandwidth()]).padding(0.15), y = d3.scaleLog([0.005, 1], [b.ih, 0]);
    WF.axY(b.g, y, b.iw, { grid: true, vals: [0.005, 0.01, 0.05, 0.1, 0.5, 1], tf: (d) => d3.format('~g')(d) }); WF.axX(b.g, x0, b.ih, { tf: (d) => MATCH[d] }); WF.yT(b, 'Likelihood-ratio p-value (log)');
    WF.hline(b.g, y(0.05), 0, b.iw, { c: C.bad, d: '4 3' }); WF.lab(b.g, b.iw - 2, y(0.05) - 5, '5%', { a: 'end', fill: C.bad });
    const bars = b.g.selectAll('rect').data(R).join('rect').attr('x', (d) => x0(d.maturity) + x1(d.model)).attr('width', x1.bandwidth()).attr('y', (d) => y(d.p)).attr('height', (d) => b.ih - y(d.p)).attr('rx', 3).style('fill', (d) => (d.model === 'withV' ? C.kal : C.c4));
    b.g.selectAll('text.v').data(R).join('text').attr('class', 'v').attr('x', (d) => x0(d.maturity) + x1(d.model) + x1.bandwidth() / 2).attr('y', (d) => y(d.p) - 5).attr('text-anchor', 'middle').style('fill', 'var(--color-fg)').style('font-size', '11px').style('font-weight', 600).text((d) => p3(d.p));
    WF.hover(bars, (d) => ({ h: MATCH[d.maturity] + ' \u00b7 ' + (d.model === 'withV' ? 'crowd variance' : 'crowd entropy'), l: [{ t: 'LR statistic ' + WF.fmt.f2(d.LR_vs_noV) }, { t: 'p ' + p3(d.p) }] }));
  }
  function bOos(el, w) {
    const C = WF.C(), R = WF.rows('qlike_tests').filter((d) => d.model === 'withV' && d.loss === S4.loss), subs = ['all OOS', 'window days', 'announcement days'], H = WF.h(w, 0.55, 250, 340);
    legendTop(el, MATS.map((m, i) => ({ c: [C.kal, C.fut, C.c4][i], t: MATCH[m] })));
    const b = WF.base(el, w, H, { l: 120, b: 44, t: 14 }), col = { '2Y': C.kal, '5Y': C.fut, '10Y': C.c4 }, ext = d3.extent(R, (d) => d.ratio_vs_noV), pad = (ext[1] - ext[0]) * 0.15 + 0.0005;
    const x = d3.scaleLinear([Math.min(ext[0], 1) - pad, Math.max(ext[1], 1) + pad], [0, b.iw]), y = d3.scaleBand(subs, [0, b.ih]).padding(0.2);
    const sl = { 'all OOS': 'All test days', 'window days': 'FOMC-window days', 'announcement days': 'Announcement days' };
    WF.axX(b.g, x, b.ih, { n: 6, tf: d3.format('.4f') }); WF.axY(b.g, y, b.iw, { tf: (d) => sl[d] }); WF.xT(b, S4.loss + ' ratio (crowd model / baseline)');
    WF.vline(b.g, x(1), 0, b.ih, { c: C.fg, d: '4 3' }); WF.lab(b.g, x(1) + 4, -3, '1: no difference', { fill: 'var(--color-fg)' });
    const sub = (d) => d.subset;
    R.forEach((d) => {
      const i = MATS.indexOf(d.maturity), cy = y(sub(d)) + y.bandwidth() * (0.2 + 0.3 * i);
      WF.hline(b.g, cy, x(1), x(d.ratio_vs_noV), { c: col[d.maturity], w: 3 }); const c = b.g.append('circle').attr('cx', x(d.ratio_vs_noV)).attr('cy', cy).attr('r', 6).style('fill', col[d.maturity]).style('stroke', 'var(--color-bg)').attr('stroke-width', 2);
      WF.lab(b.g, x(d.ratio_vs_noV) + (d.ratio_vs_noV < 1 ? -10 : 10), cy, 'p ' + p3(d.DM_p), { a: d.ratio_vs_noV < 1 ? 'end' : 'start', v: 'middle' });
      WF.hover(c, () => ({ h: MATCH[d.maturity] + ' \u00b7 ' + sl[d.subset], l: [{ t: S4.loss + ' ratio ' + d3.format('.5f')(d.ratio_vs_noV) }, { t: 'Diebold\u2013Mariano p ' + p3(d.DM_p) }, { t: d.n.toLocaleString('en') + ' days' }] }));
    });
  }
  function bCum(el, w) {
    const C = WF.C(), R = WF.rows('cum_loss').filter((d) => d.maturity === S4.mat).map((d) => ({ t: WF.pd(d.date), v: d.cum, a: d.announcement === true, q: d.qlike_diff })).sort((a, c) => a.t - c.t), H = WF.h(w, 0.58, 250, 350);
    legendTop(el, [{ c: C.fg, t: 'Cumulative loss difference' }, { c: C.bad, t: 'Announcement days' }]);
    const b = WF.base(el, w, H, { l: 52, b: 36, t: 12 }), x = d3.scaleUtc(d3.extent(R, (d) => d.t), [0, b.iw]), y = d3.scaleLinear(d3.extent(R, (d) => d.v), [b.ih, 0]).nice();
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f1 }); WF.axX(b.g, x, b.ih, { n: 7 }); WF.yT(b, 'Cumulative QLIKE difference'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
    b.g.append('path').attr('d', d3.line().x((d) => x(d.t)).y((d) => y(d.v))(R)).style('fill', 'none').style('stroke', C.fg).attr('stroke-width', 1.6);
    const ad = b.g.selectAll('circle').data(R.filter((d) => d.a)).join('circle').attr('cx', (d) => x(d.t)).attr('cy', (d) => y(d.v)).attr('r', 3.2).style('fill', C.bad).style('opacity', 0.85);
    WF.hover(ad, (d) => ({ h: d3.utcFormat('%b %-d, %Y')(d.t), l: [{ t: 'Announcement day: ' + WF.fmt.s3(d.q) }, { t: 'Cumulative ' + WF.fmt.f2(d.v) }] }));
  }
  function bDates(el, w) {
    const C = WF.C(), R = WF.rows('ann_losses').filter((d) => d.maturity === S4.mat).slice().sort((a, c) => a.qlike_diff - c.qlike_diff), H = WF.h(w, 0.58, 250, 350);
    const b = WF.base(el, w, H, { l: 52, b: 40, t: 34 }), x = d3.scaleBand(R.map((d, i) => i), [0, b.iw]).padding(0.1), y = d3.scaleLinear(d3.extent(R, (d) => d.qlike_diff), [b.ih, 0]).nice();
    const tot = d3.sum(R, (d) => d.qlike_diff), top5 = d3.sum(R.slice(0, 5), (d) => d.qlike_diff);
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: WF.fmt.f1 }); WF.xT(b, 'Announcement days, best to worst'); WF.yT(b, 'QLIKE difference'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
    const bars = b.g.selectAll('rect').data(R).join('rect').attr('x', (d, i) => x(i)).attr('width', x.bandwidth()).attr('y', (d) => y(Math.max(0, d.qlike_diff))).attr('height', (d) => Math.abs(y(d.qlike_diff) - y(0))).style('fill', (d) => (d.qlike_diff < 0 ? C.kal : C.fut));
    WF.hover(bars, (d) => ({ h: d.date, l: [{ t: 'QLIKE difference ' + WF.fmt.s3(d.qlike_diff) + (d.qlike_diff < 0 ? ' (announcement model better)' : ' (worse)') }] }));
    R.slice(0, 3).forEach((d, i) => WF.lab(b.g, x(i) + x.bandwidth() + 4, y(d.qlike_diff) + 4, d.date, { fill: 'var(--color-fg)' }));
    WF.lab(b.g, 0, -18, MATCH[S4.mat] + ': the 5 best dates are ' + WF.fmt.pc0(top5 / tot) + ' of the net gain across ' + R.length + ' announcement days', { fill: 'var(--color-fg)', w: 600 });
    WF.lab(b.g, 0, -4, 'Bars below zero: the announcement model forecast better that day.');
  }
  function bVol(el, w) {
    const C = WF.C(), R = WF.rows('vol_paths').filter((d) => d.maturity === S4.mat).map((d) => ({ t: WF.pd(d.date), b: d.sd_base, g: d.sd_garchx, a: d.A === 1 })), mat = S4.mat;
    legendTop(el, [{ c: C.mute, t: 'Plain GARCH' }, { c: C.fut, t: 'Announcement GARCH-X' }, { c: C.bad, t: 'Announcement days' }]);
    const mainH = WF.h(w, 0.4, 210, 290), ctxH = 40, b = WF.base(el, w, mainH + 42 + ctxH + 20, { l: 48, b: 4, t: 10 }), full = d3.extent(R, (d) => d.t);
    const xc = d3.scaleUtc(full, [0, b.iw]), ym = d3.scaleLinear([0, d3.max(R, (d) => Math.max(d.b, d.g)) * 1.05], [mainH, 0]), yc = d3.scaleLinear(ym.domain(), [ctxH, 0]), cid = 'wfclipv' + Math.floor(Math.random() * 1e9);
    b.svg.append('defs').append('clipPath').attr('id', cid).append('rect').attr('width', b.iw).attr('height', mainH);
    const M = b.g.append('g'), ctx = b.g.append('g').attr('transform', `translate(0,${mainH + 42})`);
    WF.yT(b, 'Conditional SD (bp/day)');
    ctx.append('path').attr('d', d3.area().x((d) => xc(d.t)).y0(ctxH).y1((d) => yc(d.b))(R)).style('fill', 'var(--cds-chart-muted)').style('opacity', 0.5);
    ctx.append('g').attr('transform', `translate(0,${ctxH})`).call(d3.axisBottom(xc).ticks(7).tickSizeOuter(0)).call((a) => { a.attr('font-size', null).attr('font-family', null); a.selectAll('text').style('fill', 'var(--color-fg-muted)').style('font-size', '10px'); a.selectAll('line,path').style('stroke', 'var(--cds-chart-axis)'); });
    function main() {
      M.selectAll('*').remove(); const dom = S4.brush[mat] || full, xm = d3.scaleUtc(dom, [0, b.iw]), vis = R.filter((d) => d.t >= dom[0] && d.t <= dom[1]);
      WF.axY(M, ym, b.iw, { grid: true, n: 5, tf: d3.format('d') }); WF.axX(M, xm, mainH, { n: 7 });
      const cl = M.append('g').attr('clip-path', `url(#${cid})`), ln = (f) => d3.line().x((d) => xm(d.t)).y((d) => ym(d[f]))(vis);
      cl.append('path').attr('d', ln('b')).style('fill', 'none').style('stroke', C.mute).attr('stroke-width', 1.4); cl.append('path').attr('d', ln('g')).style('fill', 'none').style('stroke', C.fut).attr('stroke-width', 1.4);
      const dots = cl.selectAll('circle').data(vis.filter((d) => d.a)).join('circle').attr('cx', (d) => xm(d.t)).attr('cy', (d) => ym(d.g)).attr('r', 3).style('fill', C.bad);
      WF.hover(dots, (d) => ({ h: d3.utcFormat('%b %-d, %Y')(d.t) + ' (announcement)', l: [{ c: C.mute, t: 'Plain GARCH ' + WF.fmt.f2(d.b) + 'bp' }, { c: C.fut, t: 'GARCH-X ' + WF.fmt.f2(d.g) + 'bp' }] }));
    }
    const br = d3.brushX().extent([[0, 0], [b.iw, ctxH]]).on('brush end', (ev) => { if (!ev.sourceEvent) return; S4.brush[mat] = ev.selection ? ev.selection.map(xc.invert) : null; main(); });
    const bg = ctx.append('g').call(br); if (S4.brush[mat]) bg.call(br.move, S4.brush[mat].map(xc)); bg.selectAll('.selection').style('fill', 'var(--cds-chart-muted)').style('fill-opacity', 0.25).style('stroke', 'var(--cds-chart-axis)'); main();
  }
  const NODE = (s) => String(s).replace(/_/g, ' ').replace('treasury ', 'Treasury ').replace(/^crowd/, 'Crowd (IEM)');
  function bConn(el, w) {
    const C = WF.C(), v = S4.view;
    if (v === 'bars') {
      const R = WF.rows('connect_bars'), nodes = Array.from(new Set(R.map((d) => d.node))), ms = ['TO others', 'FROM others', 'NET'], H = WF.h(w, 0.6, 250, 340), cols = { 'TO others': C.kal, 'FROM others': C.fut, NET: C.fg };
      legendTop(el, ms.map((m) => ({ c: cols[m], t: m })));
      const b = WF.base(el, w, H, { l: 46, b: 56, t: 10 }), x0 = d3.scaleBand(nodes, [0, b.iw]).padding(0.2), x1 = d3.scaleBand(ms, [0, x0.bandwidth()]).padding(0.08), y = d3.scaleLinear(d3.extent(R, (d) => d.pp), [b.ih, 0]).nice();
      WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: d3.format('d') }); WF.axX(b.g, x0, b.ih, { tf: NODE }).selectAll('text').attr('transform', 'rotate(-18)').style('text-anchor', 'end'); WF.yT(b, 'Percentage points of forecast-error variance'); WF.hline(b.g, y(0), 0, b.iw, { c: 'var(--cds-chart-axis)' });
      const bars = b.g.selectAll('rect').data(R).join('rect').attr('x', (d) => x0(d.node) + x1(d.measure)).attr('width', x1.bandwidth()).attr('y', (d) => y(Math.max(0, d.pp))).attr('height', (d) => Math.abs(y(d.pp) - y(0))).attr('rx', 2).style('fill', (d) => cols[d.measure]);
      WF.hover(bars, (d) => ({ h: NODE(d.node) + ' \u00b7 ' + d.measure, l: [{ t: WF.fmt.f2(d.pp) + ' percentage points' }] }));
    } else if (v === 'freq') {
      const R = WF.rows('connect_freq'), nodes = Array.from(new Set(R.map((d) => d.node))), bands = Array.from(new Set(R.map((d) => d.band))), wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:16px'; el.appendChild(wrap);
      legendTop(el, bands.map((bd, i) => ({ c: [C.kal, C.fut, C.c4][i % 3], t: 'Band: ' + bd })));
      const pw = w > 560 ? (w - 16) / 2 : w;
      ['TO others', 'FROM others'].forEach((m) => {
        const host = document.createElement('div'); host.style.width = pw + 'px'; wrap.appendChild(host); const b = WF.base(host, pw, WF.h(pw, 0.7, 220, 300), { l: 38, b: 54, t: 20 }), rows = R.filter((d) => d.measure === m);
        const x0 = d3.scaleBand(nodes, [0, b.iw]).padding(0.2), x1 = d3.scaleBand(bands, [0, x0.bandwidth()]).padding(0.08), y = d3.scaleLinear([0, d3.max(R, (d) => d.pp)], [b.ih, 0]).nice();
        WF.axY(b.g, y, b.iw, { grid: true, n: 5, tf: d3.format('.0f') }); WF.axX(b.g, x0, b.ih, { tf: NODE }).selectAll('text').attr('transform', 'rotate(-28)').style('text-anchor', 'end'); WF.lab(b.g, 0, -8, m + ' (pp)', { fill: 'var(--color-fg)', w: 600 });
        const bars = b.g.selectAll('rect').data(rows).join('rect').attr('x', (d) => x0(d.node) + x1(d.band)).attr('width', x1.bandwidth()).attr('y', (d) => y(d.pp)).attr('height', (d) => b.ih - y(d.pp)).attr('rx', 2).style('fill', (d) => [C.kal, C.fut, C.c4][bands.indexOf(d.band) % 3]);
        WF.hover(bars, (d) => ({ h: NODE(d.node) + ' \u00b7 ' + d.band, l: [{ t: WF.fmt.f2(d.pp) + ' pp' }] }));
      });
    } else {
      const R = WF.rows('connect_roll').map((d) => ({ t: WF.pd(d.date), s: d.series, v: d.value })), ser = Array.from(new Set(R.map((d) => d.s))), wrap = document.createElement('div'); el.appendChild(wrap);
      ser.forEach((s, i) => {
        const host = document.createElement('div'); wrap.appendChild(host); const rows = R.filter((d) => d.s === s).sort((a, c) => a.t - c.t), b = WF.base(host, w, WF.h(w, 0.28, 150, 210), { l: 46, b: 28, t: 22 });
        const x = d3.scaleUtc(d3.extent(R, (d) => d.t), [0, b.iw]), y = d3.scaleLinear(d3.extent(rows, (d) => d.v), [b.ih, 0]).nice(); WF.axY(b.g, y, b.iw, { grid: true, n: 4, tf: d3.format('.1f') }); WF.axX(b.g, x, b.ih, { n: 7 }); WF.lab(b.g, 0, -8, s, { fill: 'var(--color-fg)', w: 600 });
        b.g.append('path').attr('d', d3.line().defined((d) => Number.isFinite(d.v)).x((d) => x(d.t)).y((d) => y(d.v))(rows)).style('fill', 'none').style('stroke', [C.kal, C.fut][i % 2]).attr('stroke-width', 1.6);
      });
    }
  }
  function draw4(el, w, fresh) {
    const key = S4.step + '|' + S4.loss + '|' + S4.mat + '|' + S4.view;
    if (fresh || el.__mode !== key) { el.replaceChildren(); el.__mode = key; [bLr, bOos, bCum, bDates, bVol, bConn][S4.step](el, w); }
  }
  function ctl4() {
    const c = $('ctl-use'); c.replaceChildren(); const el = $('c-use'), rd = () => { ctl4(); WF.redraw(el); };
    if (S4.step === 1) WF.chips(c, [{ v: 'QLIKE', t: 'QLIKE' }, { v: 'MSE', t: 'MSE' }], S4.loss, (v) => { S4.loss = v; rd(); });
    else if ([2, 3, 4].includes(S4.step)) WF.chips(c, MATS.map((m) => ({ v: m, t: MATCH[m] })), S4.mat, (v) => { S4.mat = v; rd(); });
    else if (S4.step === 5) WF.chips(c, [{ v: 'bars', t: 'To / from / net' }, { v: 'freq', t: 'By frequency' }, { v: 'roll', t: 'Rolling' }], S4.view, (v) => { S4.view = v; rd(); });
  }
  function set4(i) { if (i === S4.step && $('ttl-use').textContent) return; S4.step = i; $('ttl-use').textContent = T4[i][0]; $('note-use').textContent = T4[i][1]; ctl4(); WF.redraw($('c-use')); }

  // ---- model checks ----
  const Q = { mat: '2Y' };
  function drawQq(el, w) {
    const C = WF.C(), q = WF.rows('qq').filter((d) => d.maturity === Q.mat), a = WF.rows('acf').filter((d) => d.maturity === Q.mat), g = WF.rows('garch_diag').find((d) => d.maturity === Q.mat);
    WF.chips($('ctl-qq'), MATS.map((m) => ({ v: m, t: MATCH[m] })), Q.mat, (v) => { Q.mat = v; WF.redraw(el); });
    const t = document.createElement('div'); t.className = 'cn'; t.textContent = MATCH[Q.mat] + ' yield: alpha ' + WF.fmt.f3(g.alpha) + ', beta ' + WF.fmt.f3(g.beta) + ' (sum ' + WF.fmt.f4(g.alpha_plus_beta) + '); Ljung\u2013Box p on squared residuals ' + p3(g.LB10_squared_standardised_resid_p) + ', ARCH-LM p ' + p3(g.ARCH_LM5_standardised_resid_p) + ', Engle\u2013Ng sign-bias p ' + p3(g.EngleNg_joint_signbias_p) + '; Ljung\u2013Box p on the mean equation ' + p3(g.LB10_standardised_resid_p) + '.'; el.appendChild(t);
    const wrap = document.createElement('div'); wrap.style.cssText = 'display:flex;flex-wrap:wrap;gap:20px'; el.appendChild(wrap); const pw = w > 700 ? (w - 20) / 2 : w;
    const h1 = document.createElement('div'); h1.style.width = pw + 'px'; wrap.appendChild(h1); const b = WF.base(h1, pw, WF.h(pw, 0.8, 250, 340), { l: 46, b: 42, t: 22 });
    const ex = d3.extent(q.flatMap((d) => [d.theoretical, d.sample])), x = d3.scaleLinear(ex, [0, b.iw]).nice(), y = d3.scaleLinear(ex, [b.ih, 0]).nice();
    WF.axY(b.g, y, b.iw, { grid: true, n: 6, tf: d3.format('d') }); WF.axX(b.g, x, b.ih, { n: 6, tf: d3.format('d') }); WF.xT(b, 'Theoretical quantile (fitted Student-t)'); WF.yT(b, 'Sample quantile'); WF.lab(b.g, 0, -8, 'Standardised residuals against the Student-t', { fill: 'var(--color-fg)', w: 600 });
    b.g.append('line').attr('x1', x(ex[0])).attr('y1', y(ex[0])).attr('x2', x(ex[1])).attr('y2', y(ex[1])).style('stroke', C.bad).attr('stroke-width', 1.6);
    b.g.selectAll('circle').data(q).join('circle').attr('cx', (d) => x(d.theoretical)).attr('cy', (d) => y(d.sample)).attr('r', 2.2).style('fill', C.kal).style('opacity', 0.6);
    const h2 = document.createElement('div'); h2.style.width = pw + 'px'; wrap.appendChild(h2); const b2 = WF.base(h2, pw, WF.h(pw, 0.8, 250, 340), { l: 46, b: 42, t: 22 });
    const ser = ['Standardised residuals', 'Squared standardised residuals'], x2 = d3.scaleBand(d3.range(1, 21), [0, b2.iw]).padding(0.15), yy = d3.max(a, (d) => Math.max(Math.abs(d.acf), d.band)) * 1.2, y2 = d3.scaleLinear([-yy, yy], [b2.ih, 0]);
    WF.axY(b2.g, y2, b2.iw, { grid: true, n: 5, tf: d3.format('.2f') }); WF.axX(b2.g, x2, b2.ih, { vals: [1, 5, 10, 15, 20] }); WF.xT(b2, 'Lag (days)'); WF.lab(b2.g, 0, -8, 'Residual autocorrelation', { fill: 'var(--color-fg)', w: 600 }); WF.hline(b2.g, y2(0), 0, b2.iw, { c: 'var(--cds-chart-axis)' });
    const band = a[0].band; [band, -band].forEach((v) => WF.hline(b2.g, y2(v), 0, b2.iw, { c: C.bad, d: '4 3' }));
    const sub = x2.bandwidth() / 2;
    ser.forEach((s, i) => { const rows = a.filter((d) => d.series === s), bars = b2.g.selectAll('.a' + i).data(rows).join('rect').attr('class', 'a' + i).attr('x', (d) => x2(d.lag) + i * sub).attr('width', sub).attr('y', (d) => y2(Math.max(0, d.acf))).attr('height', (d) => Math.abs(y2(d.acf) - y2(0))).style('fill', i ? C.fut : C.kal); WF.hover(bars, (d) => ({ h: s + ' \u00b7 lag ' + d.lag, l: [{ t: 'Autocorrelation ' + WF.fmt.f3(d.acf) }, { t: '95% band \u00b1' + WF.fmt.f3(d.band) }] })); });
    legendTop(h2, [{ c: C.kal, t: 'Residuals' }, { c: C.fut, t: 'Squared residuals' }]);
  }

  WF.chart('#c-how', draw3); WF.chart('#c-hb', drawHb); WF.chart('#c-use', draw4); WF.chart('#c-qq', drawQq);
  WF.scrolly('chaps-how', set3); WF.scrolly('chaps-use', set4);
  $('ttl-how').textContent = T3[0][0]; $('note-how').textContent = T3[0][1]; $('ttl-use').textContent = T4[0][0]; $('note-use').textContent = T4[0][1];
})();
