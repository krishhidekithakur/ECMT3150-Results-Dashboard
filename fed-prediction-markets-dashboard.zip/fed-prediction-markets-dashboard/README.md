# Who prices the Fed first? — interactive results

Interactive dashboard for the ECMT3150 group project (Group Chadgdp): **Fed Funds futures versus FOMC prediction markets**
(Iowa Electronic Markets 1999–2017; Kalshi 2025–26). It answers four questions and tells the story as a scroll-through,
with interactive charts you can explore:

1. **Reliable?** Brier scores and calibration (a month before the decision the prediction market is better calibrated).
2. **Early?** Does either market lead? (No stable direction of precedence.)
3. **How?** Do futures moves show up in individual Kalshi trades? (Nothing detectable.)
4. **Useful?** Does prediction-market uncertainty improve forecasts of Treasury-yield volatility? (No robust gain.)

**Live site:** `https://YOUR-USERNAME.github.io/fed-prediction-markets-dashboard/`  *(replace after enabling GitHub Pages)*

## Run it locally

No build step. Open `index.html` in a browser (everything, including the data, is bundled). Or serve the folder:

```
python -m http.server 8000     # then visit http://localhost:8000
```

## What is in this repository

| Path | What it is |
|---|---|
| `index.html` | The page: story text, layout and styles. |
| `js/` | `d3.min.js` (D3 v7), `core.js` (helpers), `act1.js`–`act3.js` (the four sections' charts), `overview.js`, `app.js`, `shim.js` (loads the bundled data) and `data.js` (all data, embedded so the page works offline). |
| `css/theme.css` | Light and dark colour themes. |
| `data/*.csv` | The 37 tidy tables behind every chart. `data/key_results.csv` lists every number quoted on the page with the R output file it came from. |

## Where the numbers come from

Every statistic on the page is read from `data/key_results.csv` at load time (nothing is typed into the text).
Rows marked `MATCH` are values our R pipeline computed and the report quotes; rows marked `DERIVED` are simple
summaries of R output files (for example, the share of the Brier gap from the three biggest meetings).
A `MATCH` is a reproducibility check, not a claim that a model is correct.

## Publish with GitHub Pages

1. Create a **public** repository (for example `fed-prediction-markets-dashboard`) and upload these files with `index.html` at the top level.
2. **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: `main`, folder `/ (root)` → Save.**
3. After a minute the site is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Data and licensing note

The tables here are derived results (scores, tests, fitted series, summaries), not raw feeds. The 15-minute expected-move series
(`modern_paths.csv`, `modern_revisions.csv`, `modern_scatter.csv`) are computed from Fed Funds futures prices supplied under our course data licences
(LSEG / Barchart / Databento). Check the licence terms before publishing them, and remove those three files (and the charts that use them)
if redistribution is not allowed.

## Credits

ECMT3150, The University of Sydney. Built with [D3](https://d3js.org). Statistical analysis in R.
